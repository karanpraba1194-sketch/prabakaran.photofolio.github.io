export default function Contact() {
  return (
    <section
      id="contact"
      style={{
        padding: '80px 40px 160px',
        position: 'relative',
        overflow: 'hidden',
        textAlign: 'center',
        background: 'var(--bg3)',
      }}
    >

      <div style={{ position: 'relative', maxWidth: 680, margin: '0 auto' }}>
        <p className="section-label reveal" style={{ marginBottom: 24 }}>Get in Touch</p>

        <h2
          className="reveal"
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 800,
            fontSize: 'clamp(38px, 5.8vw, 76px)',
            lineHeight: 1.02,
            letterSpacing: '-0.03em',
            margin: 0,
            marginBottom: 24,
            color: '#111110',
          }}
        >
          Have an idea{' '}
          <span style={{ color: '#44433F' }}>worth building?</span>
        </h2>

        <p
          className="reveal"
          style={{
            fontSize: 18,
            fontWeight: 400,
            color: 'rgba(17,17,16,0.72)',
            lineHeight: 1.75,
            marginBottom: 52,
          }}
        >
          Let&apos;s create something meaningful, useful and visually unforgettable.
        </p>

        {/* Buttons */}
        <div
          className="reveal"
          style={{
            display: 'flex',
            gap: 12,
            justifyContent: 'center',
            flexWrap: 'wrap',
            marginBottom: 56,
          }}
        >
          <a
            href="mailto:karanpraba6656@gmail.com"
            className="btn-pill"
            style={{ fontSize: 14, padding: '14px 34px' }}
          >
            ✉ Email Me
          </a>

          {[
            { label: 'LinkedIn', href: 'https://linkedin.com/in/prabakaran', icon: 'in' },
            { label: 'Behance', href: 'https://behance.net/karanpraba6656', icon: 'Be' },
          ].map((link) => (
            <a
              key={link.label}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline"
              style={{ fontSize: 14, padding: '14px 28px' }}
            >
              <span
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  background: 'rgba(17,17,16,0.08)',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 10,
                  fontWeight: 800,
                  letterSpacing: 0,
                }}
              >
                {link.icon}
              </span>
              {link.label}
            </a>
          ))}
        </div>

        {/* Behance link */}
        <div className="reveal">
          <p style={{ fontSize: 13, color: 'rgba(17,17,16,0.55)', marginBottom: 8 }}>View more work on</p>
          <a
            href="https://behance.net/karanpraba6656"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: 'rgba(17,17,16,0.55)',
              textDecoration: 'none',
              letterSpacing: '0.02em',
              transition: 'color 0.2s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#111110')}
            onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(17,17,16,0.55)')}
          >
            behance.net/karanpraba6656 →
          </a>
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          position: 'absolute',
          bottom: 40,
          left: 0,
          right: 0,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: 24,
          flexWrap: 'wrap',
          padding: '0 40px',
        }}
      >
        <p style={{ fontSize: 12, color: 'rgba(17,17,16,0.52)', margin: 0 }}>
          © 2025 Praba Karan — All rights reserved
        </p>
        <p style={{ fontSize: 12, color: 'rgba(17,17,16,0.40)', margin: 0 }}>
          Visual Designer · UI/UX · Motion
        </p>
      </div>
    </section>
  )
}
