import { useState } from 'react'
import ariMascotReveal from '../imports/motion/ari-mascot-reveal.jpg'
import businessApplicationsReel from '../imports/motion/business-applications-reel.jpg'
import chainsysAnniversary from '../imports/motion/chainsys-24-anniversary.jpg'
import chainsysBrandStory from '../imports/motion/chainsys-brand-story.jpg'
import seasonOfGratitude from '../imports/motion/season-of-gratitude.gif'
import dataMigrationExplained from '../imports/motion/data-migration-explained.jpg'
import dataQualityReconciliation from '../imports/motion/data-quality-reconciliation.jpg'
import modernErpExplainer from '../imports/motion/modern-erp-explainer.jpg'
import getCleanProcess from '../imports/motion/get-clean-process.jpg'
import smartSuiteEnterprise from '../imports/motion/smartsuite-enterprise.jpg'
import smartDataPlatform from '../imports/motion/smart-data-platform.jpg'
import dataZapOverview from '../imports/motion/datazap-overview.jpg'
import enterpriseDataManagement from '../imports/motion/enterprise-data-management.jpg'
import dataZapProductDemo from '../imports/motion/datazap-product-demo.jpg'
import dataZenseCatalogAnalytics from '../imports/motion/datazense-catalog-analytics.jpg'
import unstructuredDataCatalog from '../imports/motion/unstructured-data-catalog.jpg'
import elasticxAiPlatform from '../imports/motion/elasticx-ai-platform.png'

const motionItems = [
  {
    title: 'ElasticX AI Platform',
    type: 'AI Advancements',
    duration: '0:40',
    img: elasticxAiPlatform,
    videoUrl: 'https://drive.google.com/file/d/1yr004OWaPrj-sXGU-sC9Z4xvh2W7c2A3/preview',
  },
  {
    title: 'HRora',
    type: 'AI Advancements',
    duration: '1:30',
    img: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=600&h=360&fit=crop&auto=format',
    videoUrl: 'https://drive.google.com/file/d/1OliH-2Hm21UJWa1Y8HlgyA3UzWgovxpW/preview',
  },
  {
    title: 'Connected Business Applications',
    type: 'Motion Graphics',
    duration: '3:58',
    img: businessApplicationsReel,
    videoUrl: 'https://drive.google.com/file/d/1iOkvIkY-8nR3t_jhggs7NnZt6q676BnY/preview',
  },
  {
    title: '24 Years of ChainSys',
    type: 'Logo Animation',
    duration: '0:05',
    img: chainsysAnniversary,
    videoUrl: 'https://drive.google.com/file/d/1e_1_9sMt6MSWaGIdBl5anisnrSUpOcH9/preview',
  },
  {
    title: 'ChainSys: Designed to Succeed',
    type: 'Brand Film',
    duration: '2:54',
    img: chainsysBrandStory,
    videoUrl: 'https://drive.google.com/file/d/1Z7BAerswuBipslViOTMH21R6RmY3dPOe/preview',
  },
  {
    title: 'A Season of Gratitude',
    type: 'Motion Graphics',
    duration: '0:30',
    img: seasonOfGratitude,
    videoUrl: 'https://drive.google.com/file/d/1kT1oWK1eUOs0CE45oHaHj9_88R6Ye6s7/preview',
  },
  {
    title: 'Data Migration, Explained',
    type: 'Explainer Animation',
    duration: '2:04',
    img: dataMigrationExplained,
    videoUrl: 'https://drive.google.com/file/d/1XGrRuACbDaqfim0jfZHoy3QCKyrs73Rq/preview',
  },
  {
    title: 'Data Quality: Correct & Reconcile',
    type: 'Explainer Animation',
    duration: '0:57',
    img: dataQualityReconciliation,
    videoUrl: 'https://drive.google.com/file/d/1no_aM8qdQFCX1UgFO2djjITksjApYHKx/preview',
  },
  {
    title: 'Why Modern Businesses Need ERP',
    type: 'Explainer Animation',
    duration: '0:33',
    img: modernErpExplainer,
    videoUrl: 'https://drive.google.com/file/d/1UI4ZL0vLXQ7eA8EhDflCaZ8J4lmdNwvI/preview',
  },
  {
    title: 'Get Clean: A Smarter Data Process',
    type: 'Motion Graphics',
    duration: '0:28',
    img: getCleanProcess,
    videoUrl: 'https://drive.google.com/file/d/1WeUR5hPIBxSXJXdoRQcq5_rVYY-dTTGx/preview',
  },
  {
    title: 'SmartSuite Enterprise Data Management',
    type: 'Product Demo',
    duration: '3:39',
    img: smartSuiteEnterprise,
    videoUrl: 'https://drive.google.com/file/d/1fAcXtPbx8KKIlk7d_nb4PeC4MNoHQMC3/preview',
  },
  {
    title: 'Smart Data Platform Capabilities',
    type: 'Product Demo',
    duration: '0:55',
    img: smartDataPlatform,
    videoUrl: 'https://drive.google.com/file/d/1G5Uon2l96h3w5bc1RrYCzkNvrUYv1p8I/preview',
  },
  {
    title: 'DataZap: From Data to Decisions',
    type: 'Product Overview',
    duration: '2:31',
    img: dataZapOverview,
    videoUrl: 'https://drive.google.com/file/d/1E5sjEyB-DrGFBFw8-A7TPkT11qQ25dY9/preview',
  },
  {
    title: 'The Enterprise Data Management Story',
    type: 'Brand Film',
    duration: '6:23',
    img: enterpriseDataManagement,
    videoUrl: 'https://drive.google.com/file/d/1QCgMIHKZ5HJ_gkAZ9ZkOaIAjQ1n7Gsiu/preview',
  },
  {
    title: 'DataZap Migration & Integration Demo',
    type: 'Product Demo',
    duration: '7:09',
    img: dataZapProductDemo,
    videoUrl: 'https://drive.google.com/file/d/1PPMAwOGf4U3wcs4sp-zRzqm6OLnqX2Kr/preview',
  },
  {
    title: 'DataZense 360° Data Intelligence',
    type: 'Product Overview',
    duration: '2:26',
    img: dataZenseCatalogAnalytics,
    videoUrl: 'https://drive.google.com/file/d/1DRnZLaJfaGAF1-odbhFDrAr3oqscpzlj/preview',
  },
  {
    title: 'Making Unstructured Data Discoverable',
    type: 'Explainer Animation',
    duration: '1:24',
    img: unstructuredDataCatalog,
    videoUrl: 'https://drive.google.com/file/d/1k02ecDHGKH1Bolfhu0z9bfPdgP9XqRor/preview',
  },
  {
    title: 'Ari Mascot Reveal',
    type: 'Mascot Animation',
    duration: '0:03',
    img: ariMascotReveal,
    videoUrl: 'https://drive.google.com/file/d/1K0btkUkXcA_OXQvdsuwWOQqQMffp6YAG/preview',
  },
]

export default function MotionSection() {
  const [activeVideo, setActiveVideo] = useState<string | null>(null)

  return (
    <section
      style={{
        padding: '140px 0 80px',
        background: 'var(--bg)',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div style={{ padding: '0 40px', maxWidth: 1400, margin: '0 auto 56px' }}>
        <p className="section-label reveal" style={{ marginBottom: 16 }}>Motion</p>
        <h2
          className="reveal"
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 800,
            fontSize: 'clamp(34px, 4.8vw, 60px)',
            lineHeight: 1.06,
            letterSpacing: '-0.025em',
            margin: 0,
            color: '#111110',
          }}
        >
          Motion that brings ideas to life.
        </h2>
      </div>

      {/* Horizontal scroll gallery */}
      <div style={{ paddingLeft: 40, overflow: 'hidden' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateRows: 'repeat(2, auto)',
            gridAutoFlow: 'column',
            gridAutoColumns: 340,
            gap: 18,
            overflowX: 'auto',
            paddingRight: 40,
            paddingBottom: 20,
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            cursor: 'grab',
          }}
          onMouseDown={(e) => {
            const el = e.currentTarget
            const startX = e.pageX - el.offsetLeft
            const scrollLeft = el.scrollLeft
            el.style.cursor = 'grabbing'
            const onMove = (ev: MouseEvent) => {
              const x = ev.pageX - el.offsetLeft
              el.scrollLeft = scrollLeft - (x - startX)
            }
            const onUp = () => {
              el.style.cursor = 'grab'
              window.removeEventListener('mousemove', onMove)
              window.removeEventListener('mouseup', onUp)
            }
            window.addEventListener('mousemove', onMove)
            window.addEventListener('mouseup', onUp)
          }}
        >
          {motionItems.map((item, i) => (
            <MotionCard key={i} item={item} onPlay={item.videoUrl ? () => setActiveVideo(item.videoUrl) : undefined} />
          ))}
        </div>
      </div>

      {/* Video lightbox */}
      {activeVideo && (
        <div
          onClick={() => setActiveVideo(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.85)',
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backdropFilter: 'blur(6px)',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: 'relative',
              width: 'min(900px, 92vw)',
              aspectRatio: '16/9',
              borderRadius: 16,
              overflow: 'hidden',
              boxShadow: '0 32px 80px rgba(0,0,0,0.6)',
            }}
          >
            <iframe
              src={activeVideo}
              allow="autoplay"
              style={{ width: '100%', height: '100%', border: 'none', display: 'block' }}
            />
            <button
              onClick={() => setActiveVideo(null)}
              style={{
                position: 'absolute',
                top: 12,
                right: 12,
                width: 36,
                height: 36,
                borderRadius: '50%',
                background: 'rgba(0,0,0,0.6)',
                color: '#fff',
                border: 'none',
                fontSize: 18,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                lineHeight: 1,
              }}
            >
              ×
            </button>
          </div>
        </div>
      )}
    </section>
  )
}

function MotionCard({ item, onPlay }: { item: (typeof motionItems)[0]; onPlay?: () => void }) {
  return (
    <div
      onClick={onPlay}
      style={{
        flexShrink: 0,
        width: 340,
        borderRadius: 20,
        overflow: 'hidden',
        background: '#fff',
        border: '1px solid rgba(17,17,16,0.07)',
        cursor: onPlay ? 'pointer' : 'default',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        boxShadow: '0 2px 16px rgba(17,17,16,0.06)',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-5px)'
        e.currentTarget.style.boxShadow = '0 16px 48px rgba(17,17,16,0.1)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = '0 2px 16px rgba(17,17,16,0.06)'
      }}
    >
      {/* Thumbnail */}
      <div style={{ position: 'relative', height: 200, overflow: 'hidden' }}>
        <img
          src={item.img}
          alt={item.title}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block',
            transition: 'transform 0.5s ease',
          }}
          draggable={false}
        />
        {/* Soft overlay */}
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(17,17,16,0.42)' }} />

        {/* Play button */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 50,
            height: 50,
            borderRadius: '50%',
            background: onPlay ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.25s ease',
            boxShadow: '0 4px 16px rgba(17,17,16,0.40)',
          }}
          onMouseEnter={(e) => {
            if (!onPlay) return
            e.currentTarget.style.background = '#111110'
            e.currentTarget.style.transform = 'translate(-50%, -50%) scale(1.08)'
            const arrow = e.currentTarget.querySelector('.play-icon') as HTMLElement
            if (arrow) arrow.style.color = '#fff'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = onPlay ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.5)'
            e.currentTarget.style.transform = 'translate(-50%, -50%) scale(1)'
            const arrow = e.currentTarget.querySelector('.play-icon') as HTMLElement
            if (arrow) arrow.style.color = '#111110'
          }}
        >
          <span className="play-icon" style={{ fontSize: 16, marginLeft: 3, color: '#111110', transition: 'color 0.2s ease' }}>▶</span>
        </div>

        {/* Duration */}
        <span
          style={{
            position: 'absolute',
            bottom: 12,
            right: 12,
            fontSize: 11,
            fontWeight: 700,
            color: '#111110',
            background: 'rgba(255,255,255,0.88)',
            backdropFilter: 'blur(8px)',
            padding: '3px 9px',
            borderRadius: 100,
          }}
        >
          {item.duration}
        </span>
      </div>

      <div style={{ padding: '16px 20px 20px' }}>
        <p
          style={{
            fontSize: 10,
            fontWeight: 700,
            color: '#22C55E',
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
            marginBottom: 6,
          }}
        >
          {item.type}
        </p>
        <h4
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 700,
            fontSize: 16,
            color: '#111110',
            margin: 0,
            letterSpacing: '-0.01em',
          }}
        >
          {item.title}
        </h4>
      </div>
    </div>
  )
}
