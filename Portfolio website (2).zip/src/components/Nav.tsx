import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

const links = ['Work', 'Gallery', 'About', 'Experience', 'Skills'] as const

export default function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const location = useLocation()
  const isHome = location.pathname === '/'

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleNav = (id: string) => {
    setMenuOpen(false)
    if (!isHome) {
      window.location.href = `/#${id.toLowerCase()}`
      return
    }
    const el = document.getElementById(id.toLowerCase())
    el?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <nav
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        padding: scrolled ? '12px 40px' : '22px 40px',
        transition: 'all 0.4s cubic-bezier(0.16,1,0.3,1)',
        background: scrolled ? 'rgba(248,247,243,0.94)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(17,17,16,0.07)' : 'none',
      }}
    >
      <div style={{ maxWidth: 1400, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Logo */}
        <Link to="/" style={{ textDecoration: 'none' }}>
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: 12,
              background: '#111110',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontFamily: 'Manrope, sans-serif',
              fontWeight: 800,
              fontSize: 14,
              color: '#fff',
              letterSpacing: '-0.5px',
              transition: 'transform 0.25s ease, box-shadow 0.25s ease',
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(17,17,16,0.18)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'scale(1.06)'
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(17,17,16,0.52)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1)'
              e.currentTarget.style.boxShadow = '0 2px 8px rgba(17,17,16,0.18)'
            }}
          >
            PK
          </div>
        </Link>

        {/* Desktop nav */}
        <div style={{ display: 'flex', gap: 36, alignItems: 'center' }} className="hidden-mobile">
          {links.map((l) => (
            <button
              key={l}
              onClick={() => handleNav(l)}
              style={{
                background: 'none',
                border: 'none',
                color: 'rgba(17,17,16,0.72)',
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 500,
                fontSize: 13,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                cursor: 'pointer',
                padding: '4px 0',
                transition: 'color 0.2s ease',
                position: 'relative',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.color = '#111110')}
              onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(17,17,16,0.72)')}
            >
              {l}
            </button>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={() => handleNav('Contact')}
          className="hidden-mobile btn-pill"
          style={{ fontSize: 12, padding: '10px 22px' }}
        >
          Contact
        </button>

        {/* Mobile hamburger */}
        <button
          className="show-mobile"
          onClick={() => setMenuOpen(!menuOpen)}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            gap: 5,
            padding: 8,
          }}
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              style={{
                display: 'block',
                width: 22,
                height: 2,
                background: '#111110',
                borderRadius: 2,
                transition: 'all 0.3s ease',
                transform: menuOpen && i === 0 ? 'rotate(45deg) translate(5px, 5px)' : menuOpen && i === 2 ? 'rotate(-45deg) translate(5px, -5px)' : 'none',
                opacity: menuOpen && i === 1 ? 0 : 1,
              }}
            />
          ))}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            background: 'rgba(248,247,243,0.97)',
            backdropFilter: 'blur(20px)',
            borderBottom: '1px solid rgba(17,17,16,0.08)',
            padding: '20px 40px',
            display: 'flex',
            flexDirection: 'column',
            gap: 20,
          }}
        >
          {links.map((l) => (
            <button
              key={l}
              onClick={() => handleNav(l)}
              style={{
                background: 'none',
                border: 'none',
                color: '#111110',
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 600,
                fontSize: 16,
                textAlign: 'left',
                cursor: 'pointer',
                letterSpacing: '0.04em',
              }}
            >
              {l}
            </button>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
        }
        @media (min-width: 769px) {
          .show-mobile { display: none !important; }
        }
      `}</style>
    </nav>
  )
}
