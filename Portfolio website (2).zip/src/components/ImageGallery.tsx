import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { projects } from '../data/projects'
import lionLogoDesign from '../imports/lion-logo-design.png'
import businessTechIconSet from '../imports/business-tech-icon-set.png'
import posterDesignThumbnail from '../imports/poster-design-thumbnail.png'
import storyboardThumbnail from '../imports/storyboard-thumbnail.png'

interface GalleryItem {
  id: string
  title: string
  category: string
  tag: string
  year: string
  img: string
  caseStudyId?: string
  fit?: 'cover' | 'contain'
}

const galleryFilters = ['All', 'Storyboard', 'Branding', 'Poster Design']

const galleryItems: GalleryItem[] = [
  {
    id: 'poster-design',
    title: 'Poster Design Collection',
    category: 'Campaigns / Webinars / Events',
    tag: 'Poster Design',
    year: '2024',
    img: posterDesignThumbnail,
    fit: 'cover',
  },
  {
    id: 'lion-logo-design',
    title: 'Ari Logo',
    category: 'Logo Design / Brand Identity',
    tag: 'Branding',
    year: '2024',
    img: lionLogoDesign,
    fit: 'contain',
  },
  ...projects
    .filter(
      (project) =>
        project.tag === 'UI/UX' ||
        project.tag === 'Branding' ||
        project.id === 'datazap',
    )
    .map((project) => ({
      id: project.id,
      title: project.id === 'sab-loglens' ? 'Business & Tech Icon Set' : project.title,
      category: project.id === 'sab-loglens' ? '200+ Scalable Icons' : project.category,
      tag:
        project.id === 'sab-loglens'
          ? 'Icons'
          : project.id === 'smartlet-etl'
            ? 'Storyboard'
            : project.tag,
      year: project.year,
      img:
        project.id === 'sab-loglens'
          ? businessTechIconSet
          : project.id === 'smartlet-etl'
            ? storyboardThumbnail
            : project.img,
      caseStudyId:
        project.id === 'sab-loglens' || project.id === 'datazap'
          ? undefined
          : project.id,
    })),
]

function getCardPosition(index: number, current: number, length: number) {
  let offset = (index - current + length) % length
  if (offset > length / 2) offset -= length

  if (offset === -2) return 'far-left'
  if (offset === -1) return 'left'
  if (offset === 0) return 'active'
  if (offset === 1) return 'right'
  if (offset === 2) return 'far-right'
  return 'hidden'
}

export default function ImageGallery() {
  const navigate = useNavigate()
  const [activeFilter, setActiveFilter] = useState('All')
  const [current, setCurrent] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  const galleryProjects =
    activeFilter === 'All'
      ? galleryItems
      : galleryItems.filter((project) => project.tag === activeFilter)
  const activeProject = galleryProjects[current] ?? galleryProjects[0]

  useEffect(() => {
    if (
      isPaused ||
      galleryProjects.length <= 1 ||
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      return
    }

    const timer = window.setInterval(() => {
      setCurrent((index) => (index + 1) % galleryProjects.length)
    }, 4000)

    return () => window.clearInterval(timer)
  }, [activeFilter, galleryProjects.length, isPaused])

  const selectFilter = (filter: string) => {
    setActiveFilter(filter)
    setCurrent(0)
  }

  const move = (direction: number) => {
    setCurrent((index) => (index + direction + galleryProjects.length) % galleryProjects.length)
  }

  return (
    <section
      id="gallery"
      aria-labelledby="gallery-title"
      style={{ padding: '112px 40px 96px', background: 'var(--bg2)', overflow: 'hidden' }}
    >
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <div className="diary-heading reveal">
          <p className="section-label diary-heading__label">Gallery</p>
          <h2 id="gallery-title">My Visual Diary</h2>
          <p>
            A glimpse into my design journey through selected interfaces,
            visual systems, and motion experiences.
          </p>
        </div>

        <div className="diary-filters reveal" aria-label="Filter gallery projects">
          {galleryFilters.map((filter) => (
            <button
              key={filter}
              type="button"
              className={activeFilter === filter ? 'diary-filter diary-filter--active' : 'diary-filter'}
              aria-pressed={activeFilter === filter}
              onClick={() => selectFilter(filter)}
            >
              {filter}
            </button>
          ))}
          <button
            type="button"
            className="diary-filter diary-filter--view"
            onClick={() => document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' })}
          >
            View work <span aria-hidden="true">→</span>
          </button>
        </div>

        <div
          className="diary-stage reveal"
          aria-live="polite"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onFocusCapture={() => setIsPaused(true)}
          onBlurCapture={(event) => {
            if (!event.currentTarget.contains(event.relatedTarget)) {
              setIsPaused(false)
            }
          }}
        >
          <div className="diary-stage__glow" />
          {galleryProjects.map((project, index) => {
            const position = getCardPosition(index, current, galleryProjects.length)
            const isActive = position === 'active'
            const isHidden = position === 'hidden'
            const opensCaseStudy = isActive && Boolean(project.caseStudyId)
            const opensPosterCollection = isActive && project.id === 'poster-design'
            const opensIconCollection = isActive && project.id === 'sab-loglens'
            const opensGifCollection = isActive && project.id === 'datazap'
            const opensProject =
              opensCaseStudy ||
              opensPosterCollection ||
              opensIconCollection ||
              opensGifCollection

            return (
              <div
                key={project.id}
                className={`diary-card diary-card--${position}${project.fit === 'contain' ? ' diary-card--artwork' : ''}${project.id === 'poster-design' ? ' diary-card--poster' : ''}`}
                role={isActive && !opensProject ? undefined : 'button'}
                tabIndex={isHidden || (isActive && !opensProject) ? -1 : 0}
                aria-hidden={isHidden}
                aria-label={opensProject ? `Open ${project.title}` : `Show ${project.title}`}
                onClick={() => {
                  if (opensCaseStudy) navigate(`/project/${project.caseStudyId}`)
                  else if (opensPosterCollection) navigate('/poster-design')
                  else if (opensIconCollection) navigate('/icons')
                  else if (opensGifCollection) navigate('/gif-animation')
                  else setCurrent(index)
                }}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault()
                    if (opensCaseStudy) navigate(`/project/${project.caseStudyId}`)
                    else if (opensPosterCollection) navigate('/poster-design')
                    else if (opensIconCollection) navigate('/icons')
                    else if (opensGifCollection) navigate('/gif-animation')
                    else setCurrent(index)
                  }
                }}
              >
                <img src={project.img} alt="" />
                <div className="diary-card__shade" />
                <div className="diary-card__tag">{project.tag}</div>
                {opensProject && (
                  <div className="diary-card__open" aria-hidden="true">↗</div>
                )}
              </div>
            )
          })}
        </div>

        {activeProject && (
          <div className="diary-controls reveal">
            <div className="diary-caption">
              <span>{String(current + 1).padStart(2, '0')}</span>
              <div>
                <p>{activeProject.title}</p>
                <span>{activeProject.category}</span>
              </div>
            </div>
            <div className="diary-navigation">
              <button type="button" onClick={() => move(-1)} aria-label="Previous image">←</button>
              <span>
                {String(current + 1).padStart(2, '0')} / {String(galleryProjects.length).padStart(2, '0')}
              </span>
              <button type="button" onClick={() => move(1)} aria-label="Next image">→</button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .diary-heading {
          max-width: 560px;
          margin: 0 auto;
          text-align: center;
        }
        .diary-heading__label {
          margin: 0 0 14px;
        }
        .diary-heading h2 {
          margin: 0;
          color: var(--fg);
          font-family: 'Manrope', sans-serif;
          font-size: clamp(40px, 5vw, 68px);
          font-weight: 700;
          line-height: 1;
          letter-spacing: -0.055em;
        }
        .diary-heading > p:last-child {
          max-width: 430px;
          margin: 18px auto 0;
          color: rgba(17,17,16,0.58);
          font-size: 13px;
          line-height: 1.65;
        }
        .diary-filters {
          display: flex;
          justify-content: center;
          gap: 8px;
          margin: 48px auto 12px;
          flex-wrap: wrap;
        }
        .diary-filter {
          min-height: 38px;
          padding: 0 18px;
          border: 1px solid var(--border-strong);
          border-radius: 100px;
          color: rgba(17,17,16,0.72);
          background: transparent;
          font-family: 'Manrope', sans-serif;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: color 0.25s ease, background 0.25s ease, border-color 0.25s ease, transform 0.25s ease;
        }
        .diary-filter:hover {
          color: var(--fg);
          border-color: var(--fg);
          transform: translateY(-2px);
        }
        .diary-filter--active {
          color: white;
          border-color: var(--fg);
          background: var(--fg);
        }
        .diary-filter--view {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding-right: 15px;
        }
        .diary-filter--view span {
          font-size: 14px;
        }
        .diary-stage {
          position: relative;
          height: 500px;
          margin: 24px -40px 0;
        }
        .diary-stage__glow {
          position: absolute;
          right: 8%;
          bottom: 34px;
          left: 8%;
          height: 120px;
          border-radius: 50%;
          background: rgba(17,17,16,0.09);
          filter: blur(36px);
          transform: scaleY(0.35);
        }
        .diary-card {
          position: absolute;
          top: 50%;
          left: 50%;
          width: clamp(429px, 44vw, 605px);
          aspect-ratio: 808 / 632;
          overflow: hidden;
          border: 1px solid rgba(255,255,255,0.5);
          border-radius: var(--radius);
          background: var(--bg3);
          box-shadow: 0 24px 60px rgba(17,17,16,0.16);
          cursor: pointer;
          transition:
            transform 0.7s cubic-bezier(0.16, 1, 0.3, 1),
            width 0.7s cubic-bezier(0.16, 1, 0.3, 1),
            opacity 0.45s ease,
            filter 0.45s ease;
        }
        .diary-card:focus-visible {
          outline: 3px solid var(--accent-green);
          outline-offset: 4px;
        }
        .diary-card img {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          transition: transform 0.65s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .diary-card:hover img {
          transform: scale(1.04);
        }
        .diary-card--active {
          z-index: 5;
          transform: translate(-50%, -50%);
          filter: saturate(1.05);
        }
        .diary-card--artwork {
          background: white;
        }
        .diary-card--artwork img {
          object-fit: contain;
        }
        .diary-card--poster img {
          object-position: right center;
        }
        .diary-card--left {
          z-index: 4;
          transform: translate(calc(-50% - 429px), -50%) scale(0.94);
        }
        .diary-card--right {
          z-index: 4;
          transform: translate(calc(-50% + 429px), -50%) scale(0.94);
        }
        .diary-card--far-left {
          z-index: 3;
          opacity: 0.86;
          transform: translate(calc(-50% - 814px), -50%) scale(0.82);
          filter: saturate(0.75);
        }
        .diary-card--far-right {
          z-index: 3;
          opacity: 0.86;
          transform: translate(calc(-50% + 814px), -50%) scale(0.82);
          filter: saturate(0.75);
        }
        .diary-card--hidden {
          z-index: 1;
          opacity: 0;
          pointer-events: none;
          transform: translate(-50%, -50%) scale(0.72);
        }
        .diary-card__shade {
          position: absolute;
          inset: 0;
          background: linear-gradient(to top, rgba(10,10,9,0.65), transparent 44%);
          pointer-events: none;
        }
        .diary-card__tag {
          position: absolute;
          top: 16px;
          left: 16px;
          padding: 7px 11px;
          border: 1px solid rgba(255,255,255,0.32);
          border-radius: 100px;
          color: white;
          background: rgba(17,17,16,0.26);
          backdrop-filter: blur(10px);
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .diary-card__open {
          position: absolute;
          right: 18px;
          bottom: 18px;
          display: grid;
          width: 38px;
          height: 38px;
          place-items: center;
          border-radius: 50%;
          color: var(--fg);
          background: white;
          font-size: 16px;
          transition: transform 0.25s ease;
        }
        .diary-card--active:hover .diary-card__open {
          transform: rotate(8deg);
        }
        .diary-controls {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 28px;
          max-width: 760px;
          margin: 12px auto 0;
        }
        .diary-caption {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .diary-caption > span {
          color: var(--accent-green);
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.1em;
        }
        .diary-caption p {
          margin: 0 0 3px;
          color: var(--fg);
          font-size: 14px;
          font-weight: 700;
          letter-spacing: -0.01em;
        }
        .diary-caption div span {
          color: rgba(17,17,16,0.48);
          font-size: 9px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }
        .diary-navigation {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .diary-navigation button {
          display: grid;
          width: 38px;
          height: 38px;
          place-items: center;
          border: 1px solid var(--border-strong);
          border-radius: 50%;
          color: var(--fg);
          background: transparent;
          font-size: 15px;
          cursor: pointer;
          transition: color 0.2s ease, background 0.2s ease, transform 0.2s ease;
        }
        .diary-navigation button:hover {
          color: white;
          background: var(--fg);
          transform: translateY(-2px);
        }
        .diary-navigation span {
          min-width: 48px;
          color: rgba(17,17,16,0.46);
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.1em;
          text-align: center;
        }
        @media (max-width: 768px) {
          .diary-filters {
            justify-content: flex-start;
            margin-right: -40px;
            padding-right: 40px;
            overflow-x: auto;
            flex-wrap: nowrap;
            scrollbar-width: none;
          }
          .diary-filters::-webkit-scrollbar {
            display: none;
          }
          .diary-filter {
            flex: 0 0 auto;
          }
          .diary-stage {
            height: 420px;
          }
          .diary-card {
            width: min(96vw, 484px);
          }
          .diary-card--left {
            transform: translate(calc(-50% - 70vw), -50%) scale(0.88);
          }
          .diary-card--right {
            transform: translate(calc(-50% + 70vw), -50%) scale(0.88);
          }
          .diary-card--far-left,
          .diary-card--far-right {
            opacity: 0;
            pointer-events: none;
          }
          .diary-controls {
            align-items: flex-start;
            flex-direction: column;
          }
          .diary-navigation {
            align-self: center;
          }
        }
      `}</style>
    </section>
  )
}
