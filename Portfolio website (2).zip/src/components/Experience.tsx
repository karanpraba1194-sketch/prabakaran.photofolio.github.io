const roles = [
  {
    period: '2025 – Present',
    role: 'UI/UX & Product Designer',
    company: 'Chainsys',
    type: 'Full-time',
    tags: ['Product Design', 'UI/UX', 'Design Systems', 'SaaS'],
    desc: 'Leading UI/UX design for enterprise SaaS products. Designing complex dashboards, product workflows, and design systems. Collaborating with engineering teams to ship polished, user-centered experiences.',
    highlight: true,
  },
  {
    period: '2018 – 2025',
    role: 'Motion Graphics / Visual Designer',
    company: 'Chainsys',
    type: 'Full-time',
    tags: ['Motion Graphics', 'Visual Design', 'Branding', 'Video Production'],
    desc: 'Produced all motion graphics and visual design output — product demo videos, explainer animations, brand films, marketing campaigns, and social content. Built the visual identity for multiple product lines.',
    highlight: false,
  },
  {
    period: '2017',
    role: 'Started Creative Journey',
    company: 'Independent',
    type: 'Freelance',
    tags: ['Visual Design', 'Branding'],
    desc: 'Began professional design work with brand identity and visual communication projects, establishing a foundation in design craft and client collaboration.',
    highlight: false,
  },
]

export default function Experience() {
  return (
    <section id="experience" style={{ padding: '140px 40px 80px', background: 'var(--bg3)' }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <p className="section-label reveal" style={{ marginBottom: 16 }}>Background</p>
        <h2
          className="reveal"
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 800,
            fontSize: 'clamp(34px, 4.8vw, 60px)',
            lineHeight: 1.06,
            letterSpacing: '-0.025em',
            margin: 0,
            marginBottom: 72,
            color: '#111110',
          }}
        >
          Experience
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {roles.map((r, i) => (
            <ExperienceRow key={i} role={r} index={i} isLast={i === roles.length - 1} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ExperienceRow({
  role,
  index,
  isLast,
}: {
  role: (typeof roles)[0]
  index: number
  isLast: boolean
}) {
  return (
    <div
      className="reveal"
      style={{
        transitionDelay: `${index * 0.1}s`,
        position: 'relative',
        paddingBottom: isLast ? 0 : 20,
        paddingLeft: 32,
      }}
    >
      {/* Vertical line */}
      {!isLast && (
        <div
          style={{
            position: 'absolute',
            left: 7,
            top: 24,
            bottom: 0,
            width: 1,
            background: 'linear-gradient(to bottom, rgba(17,17,16,0.12), transparent)',
          }}
        />
      )}

      {/* Dot */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 6,
          width: 16,
          height: 16,
          borderRadius: '50%',
          background: role.highlight ? '#22C55E' : 'rgba(17,17,16,0.12)',
          border: role.highlight ? 'none' : '1px solid rgba(17,17,16,0.18)',
          boxShadow: role.highlight ? '0 0 14px rgba(34,197,94,0.35)' : 'none',
        }}
      />

      <div
        style={{
          background: role.highlight ? '#fff' : 'rgba(17,17,16,0.03)',
          border: `1px solid ${role.highlight ? 'rgba(17,17,16,0.09)' : 'rgba(17,17,16,0.07)'}`,
          borderRadius: 18,
          padding: '26px 30px',
          marginBottom: isLast ? 0 : 20,
          transition: 'all 0.28s ease',
          boxShadow: role.highlight ? '0 4px 24px rgba(17,17,16,0.07)' : 'none',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.boxShadow = '0 8px 40px rgba(17,17,16,0.1)'
          e.currentTarget.style.transform = 'translateX(4px)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.boxShadow = role.highlight ? '0 4px 24px rgba(17,17,16,0.07)' : 'none'
          e.currentTarget.style.transform = 'translateX(0)'
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginBottom: 12,
            flexWrap: 'wrap',
            gap: 12,
          }}
        >
          <div>
            <h3
              style={{
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 700,
                fontSize: 19,
                color: '#111110',
                margin: 0,
                marginBottom: 5,
                letterSpacing: '-0.01em',
              }}
            >
              {role.role}
            </h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 14, color: role.highlight ? '#22C55E' : 'rgba(17,17,16,0.72)', fontWeight: 600 }}>
                {role.company}
              </span>
              <span style={{ fontSize: 11, color: 'rgba(17,17,16,0.48)' }}>·</span>
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  color: 'rgba(17,17,16,0.62)',
                  background: 'rgba(17,17,16,0.06)',
                  padding: '2px 9px',
                  borderRadius: 100,
                  letterSpacing: '0.04em',
                }}
              >
                {role.type}
              </span>
            </div>
          </div>
          <span style={{ fontSize: 13, fontWeight: 600, color: 'rgba(17,17,16,0.58)', letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>
            {role.period}
          </span>
        </div>

        <p style={{ fontSize: 14, color: 'rgba(17,17,16,0.74)', lineHeight: 1.75, margin: 0, marginBottom: 16 }}>
          {role.desc}
        </p>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {role.tags.map((t) => (
            <span
              key={t}
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: 'rgba(17,17,16,0.72)',
                background: 'rgba(17,17,16,0.05)',
                border: '1px solid rgba(17,17,16,0.09)',
                borderRadius: 100,
                padding: '3px 10px',
                letterSpacing: '0.04em',
              }}
            >
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
