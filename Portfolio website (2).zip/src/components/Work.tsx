import { useNavigate } from 'react-router-dom'
import { projects } from '../data/projects'

export default function Work() {
  const navigate = useNavigate()

  const msrtcProject = projects.find((project) => project.id === 'msrtc')
  const workProjects = projects.flatMap((project) => {
    if (project.id === 'datazap') return msrtcProject ? [msrtcProject] : []
    if (
      project.id === 'msrtc' ||
      project.id === 'currency-exchange' ||
      project.id === 'sab-loglens'
    ) {
      return []
    }
    return [project]
  })
  return (
    <section id="work" style={{ padding: '140px 40px', background: 'var(--bg3)' }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: 64 }}>
          <p className="section-label reveal" style={{ marginBottom: 16 }}>Portfolio</p>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 32 }}>
            <h2
              className="reveal"
              style={{
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 800,
                fontSize: 'clamp(34px, 4.8vw, 60px)',
                lineHeight: 1.06,
                letterSpacing: '-0.025em',
                margin: 0,
                color: '#111110',
              }}
            >
              UI/UX &amp; Web Designer
            </h2>
            <p className="reveal" style={{ fontSize: 15, color: 'rgba(17,17,16,0.68)', maxWidth: 360, lineHeight: 1.7, margin: 0 }}>
              A collection of products, interfaces, visual systems and motion experiences.
            </p>
          </div>
        </div>

        {/* Projects grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(12, minmax(0, 1fr))',
            gap: 24,
          }}
          className="projects-grid"
        >
          {workProjects.map((p, i) => (
            <ProjectCard
              key={p.id}
              project={p}
              index={i}
              onClick={() => {
                if (p.id === 'datazap') navigate('/gif-animation')
                else if (p.id === 'elasticx-erp') navigate('/elasticx')
                else if (p.id === 'msrtc') navigate('/msrtc')
                else if (p.id === 'template-hub') navigate('/template-hub')
                else if (p.id === 'ari-ai') navigate('/ari-ai')
                else if (p.id === 'smart-app-builder') navigate('/datazense')
                else if (p.id === 'elasticx-website') navigate('/datazap')
                else if (p.id === 'smartlet-etl') navigate('/smart-app-builder')
                else navigate(`/project/${p.id}`)
              }}
            />
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 1100px) {
          .project-card-shell { grid-column: span 6 !important; }
        }
        @media (max-width: 768px) {
          .project-card-shell { grid-column: 1 / -1 !important; }
        }
      `}</style>
    </section>
  )
}

function ProjectCard({ project: p, index, onClick }: { project: (typeof projects)[0]; index: number; onClick: () => void }) {
  return (
    <div
      className="reveal project-card-shell"
      style={{
        gridColumn: index < 3 ? 'span 4' : 'span 3',
        transitionDelay: `${(index % 4) * 0.07}s`,
      }}
      onClick={onClick}
    >
      <div
        style={{
          background: '#fff',
          borderRadius: 20,
          overflow: 'hidden',
          border: '1px solid rgba(17,17,16,0.07)',
          cursor: 'pointer',
          transition: 'transform 0.4s cubic-bezier(0.16,1,0.3,1), box-shadow 0.4s ease',
          boxShadow: '0 2px 16px rgba(17,17,16,0.06)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'translateY(-6px)'
          e.currentTarget.style.boxShadow = '0 16px 56px rgba(17,17,16,0.1)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translateY(0)'
          e.currentTarget.style.boxShadow = '0 2px 16px rgba(17,17,16,0.06)'
        }}
      >
        {/* Image */}
        <div style={{ position: 'relative', overflow: 'hidden', height: 228 }}>
          <img
            src={p.img}
            alt={p.title}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              objectPosition: p.id === 'template-hub' ? 'center 55%' : 'center',
              transition: 'transform 0.6s cubic-bezier(0.16,1,0.3,1)',
              display: 'block',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.04)')}
            onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
          />
          {/* Soft bottom fade */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'linear-gradient(to bottom, transparent 55%, rgba(255,255,255,0.15))',
              pointerEvents: 'none',
            }}
          />
          {/* Category badge */}
          <div
            style={{
              position: 'absolute',
              top: 14,
              left: 14,
              background: 'rgba(255,255,255,0.88)',
              backdropFilter: 'blur(8px)',
              borderRadius: 100,
              padding: '4px 12px',
              fontSize: 11,
              fontWeight: 700,
              color: '#111110',
              letterSpacing: '0.07em',
            }}
          >
            {p.tag}
          </div>
          {/* Year */}
          <div
            style={{
              position: 'absolute',
              top: 14,
              right: 14,
              fontSize: 11,
              fontWeight: 600,
              color: 'rgba(17,17,16,0.76)',
              background: 'rgba(255,255,255,0.75)',
              backdropFilter: 'blur(8px)',
              padding: '3px 9px',
              borderRadius: 100,
              letterSpacing: '0.07em',
            }}
          >
            {p.year}
          </div>
        </div>

        {/* Content */}
        <div style={{ padding: '24px 24px 22px' }}>
          <h3
            style={{
              fontFamily: 'Manrope, sans-serif',
              fontWeight: 700,
              fontSize: 19,
              color: '#111110',
              margin: 0,
              marginBottom: 8,
              letterSpacing: '-0.01em',
            }}
          >
            {p.title}
          </h3>
          <p style={{ fontSize: 13, color: 'rgba(17,17,16,0.68)', margin: 0, marginBottom: 18, lineHeight: 1.65 }}>
            {p.desc}
          </p>

          {/* Tools */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 20 }}>
            {p.tools.map((t) => (
              <span
                key={t}
                style={{
                  fontSize: 11,
                  fontWeight: 500,
                  color: 'rgba(17,17,16,0.62)',
                  background: 'rgba(17,17,16,0.05)',
                  borderRadius: 6,
                  padding: '3px 8px',
                }}
              >
                {t}
              </span>
            ))}
          </div>

          {/* View link */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: '#111110', letterSpacing: '0.02em' }}>
              {p.id === 'datazap'
                ? 'View Animations'
                : p.id === 'elasticx-erp'
                  ? 'View Live Project'
                  : p.id === 'msrtc'
                    ? 'View Prototype'
                    : p.id === 'template-hub'
                      ? 'View Figma File'
                      : p.id === 'ari-ai'
                        ? 'View Prototype'
                        : p.id === 'smart-app-builder'
                          ? 'View Prototype'
                          : p.id === 'elasticx-website'
                            ? 'View Prototype'
                            : p.id === 'smartlet-etl'
                              ? 'View Prototype'
                  : 'View Case Study'}
            </span>
            <span style={{ color: '#111110', fontSize: 15, lineHeight: 1 }}>→</span>
          </div>
        </div>
      </div>
    </div>
  )
}
