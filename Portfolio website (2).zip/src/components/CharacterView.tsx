import characterImg from '../imports/c7d5706c-8a4c-4b7b-ad04-9938dfe4e22a.png'

export default function CharacterView() {
  return (
    <div
      style={{
        position: 'relative',
        width: 420,
        height: 520,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        flexShrink: 0,
        marginLeft: '-10%',
      }}
    >
      {/* Character image */}
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: '50%',
          transform: 'translateX(-60%)',
          width: 380,
          height: 500,
          zIndex: 2,
          pointerEvents: 'none',
        }}
      >
        <img
          src={characterImg}
          alt="Praba Karan — Visual Designer"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain',
            objectPosition: 'bottom center',
            display: 'block',
            userSelect: 'none',
          }}
          draggable={false}
        />
      </div>
    </div>
  )
}
