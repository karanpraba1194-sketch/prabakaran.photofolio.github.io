import profileImg from '../imports/WhatsApp_Image_2026-06-09_at_06.13.50.jpeg'

const timeline = [
  { year: '2017', label: 'Started creative journey' },
  { year: '2018–2025', label: 'Motion Graphics / Visual Design' },
  { year: '2025–Present', label: 'UI/UX & Product Design' },
]

const disciplines = [
  'Product Design', 'UI/UX Design', 'SaaS Interfaces',
  'Enterprise Applications', 'Motion Graphics',
  'Product Demo Videos', 'Branding', 'Website Design',
  'Marketing Visuals', 'Animation',
]

export default function About() {
  return (
    <section
      id="about"
      style={{
        padding: '140px 40px',
        position: 'relative',
        background: 'var(--bg)',
      }}
    >
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 380px',
            gap: 100,
            alignItems: 'center',
          }}
          className="about-grid"
        >
          {/* Left */}
          <div style={{ paddingLeft: '10%' }}>
            <p className="section-label reveal" style={{ marginBottom: 18 }}>About</p>
            <h2
              className="reveal"
              style={{
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 800,
                fontSize: 'clamp(34px, 4.8vw, 60px)',
                lineHeight: 1.06,
                letterSpacing: '-0.025em',
                margin: 0,
                marginBottom: 32,
                color: '#111110',
              }}
            >
              Designing with purpose.{' '}
              <span style={{ color: '#44433F' }}>Creating with impact.</span>
            </h2>

            <p
              className="reveal"
              style={{
                fontSize: 17,
                fontWeight: 400,
                color: 'rgba(17,17,16,0.76)',
                lineHeight: 1.85,
                marginBottom: 36,
                maxWidth: 540,
              }}
            >
              Senior designer with{' '}
              <strong style={{ color: '#111110', fontWeight: 700 }}>9+ years of professional experience</strong>{' '}
              across visual design, motion graphics, and UI/UX. I bring ideas from concept to polished product — blending visual craft with user-centered thinking.
            </p>

            {/* Discipline tags */}
            <div className="reveal" style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 56 }}>
              {disciplines.map((d) => (
                <span
                  key={d}
                  style={{
                    fontSize: 12,
                    fontWeight: 500,
                    color: 'rgba(17,17,16,0.72)',
                    background: 'rgba(17,17,16,0.04)',
                    border: '1px solid rgba(17,17,16,0.09)',
                    borderRadius: 100,
                    padding: '6px 14px',
                    letterSpacing: '0.02em',
                    transition: 'all 0.2s ease',
                    cursor: 'default',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#111110'
                    e.currentTarget.style.borderColor = '#111110'
                    e.currentTarget.style.color = '#fff'
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(17,17,16,0.04)'
                    e.currentTarget.style.borderColor = 'rgba(17,17,16,0.09)'
                    e.currentTarget.style.color = 'rgba(17,17,16,0.72)'
                  }}
                >
                  {d}
                </span>
              ))}
            </div>

            {/* Timeline */}
            <div className="reveal">
              <p style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(17,17,16,0.55)', marginBottom: 24 }}>
                Journey
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                {timeline.map((t, i) => (
                  <div
                    key={i}
                    style={{
                      display: 'flex',
                      gap: 24,
                      alignItems: 'flex-start',
                      paddingBottom: i < timeline.length - 1 ? 24 : 0,
                      position: 'relative',
                    }}
                  >
                    {i < timeline.length - 1 && (
                      <div
                        style={{
                          position: 'absolute',
                          left: 68,
                          top: 22,
                          bottom: 0,
                          width: 1,
                          background: 'linear-gradient(to bottom, rgba(17,17,16,0.12), transparent)',
                        }}
                      />
                    )}
                    <span
                      style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: i === timeline.length - 1 ? '#22C55E' : '#111110',
                        minWidth: 60,
                        fontVariantNumeric: 'tabular-nums',
                        paddingTop: 2,
                      }}
                    >
                      {t.year}
                    </span>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div
                        style={{
                          width: 8,
                          height: 8,
                          borderRadius: '50%',
                          background: i === timeline.length - 1 ? '#22C55E' : 'rgba(17,17,16,0.40)',
                          flexShrink: 0,
                          marginTop: 4,
                        }}
                      />
                      <span style={{ fontSize: 15, fontWeight: 500, color: 'rgba(17,17,16,0.6)', lineHeight: 1.4 }}>
                        {t.label}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right — profile card */}
          <div className="reveal-right about-card-col">
            <div
              className="float-1"
              style={{
                position: 'relative',
                width: 320,
              }}
            >
              {/* Main card */}
              <div
                style={{
                  background: '#fff',
                  borderRadius: 24,
                  padding: 28,
                  boxShadow: '0 8px 48px rgba(17,17,16,0.1), 0 2px 8px rgba(17,17,16,0.05)',
                  border: '1px solid rgba(17,17,16,0.06)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 0,
                }}
              >
                {/* Profile photo */}
                <div
                  style={{
                    width: '100%',
                    height: 320,
                    borderRadius: 16,
                    overflow: 'hidden',
                    marginBottom: 22,
                    background: '#F0EFE9',
                  }}
                >
                  <img
                    src={profileImg}
                    alt="Praba Karan"
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      objectPosition: 'center 22%',
                      display: 'block',
                      transition: 'transform 0.5s ease',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.04)')}
                    onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                  />
                </div>

                <h3
                  style={{
                    fontFamily: 'Manrope, sans-serif',
                    fontWeight: 800,
                    fontSize: 22,
                    color: '#111110',
                    margin: 0,
                    marginBottom: 4,
                    letterSpacing: '-0.01em',
                  }}
                >
                  Praba Karan
                </h3>
                <p style={{ fontSize: 13, color: 'rgba(17,17,16,0.65)', margin: 0, marginBottom: 20, letterSpacing: '0.04em' }}>
                  Visual Designer / UI/UX
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 0, borderTop: '1px solid rgba(17,17,16,0.07)', paddingTop: 16 }}>
                  {[
                    { label: 'Experience', value: '9+ Years' },
                    { label: 'Company', value: 'Chainsys' },
                    { label: 'Speciality', value: 'Motion + Product' },
                  ].map((s, i, arr) => (
                    <div
                      key={s.label}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        padding: '11px 0',
                        borderBottom: i < arr.length - 1 ? '1px solid rgba(17,17,16,0.06)' : 'none',
                      }}
                    >
                      <span style={{ fontSize: 12, color: 'rgba(17,17,16,0.62)', fontWeight: 500 }}>{s.label}</span>
                      <span style={{ fontSize: 13, color: '#111110', fontWeight: 700 }}>{s.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Small floating badge */}
              <div
                className="float-2"
                style={{
                  position: 'absolute',
                  bottom: -18,
                  right: -22,
                  background: '#fff',
                  borderRadius: 16,
                  padding: '13px 18px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 11,
                  boxShadow: '0 4px 24px rgba(17,17,16,0.1)',
                  border: '1px solid rgba(17,17,16,0.06)',
                  animationDelay: '2s',
                }}
              >
                <div
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 9,
                    background: '#111110',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 14,
                  }}
                >
                  🎨
                </div>
                <div>
                  <p style={{ fontSize: 12, fontWeight: 700, color: '#111110', margin: 0 }}>200+ Projects</p>
                  <p style={{ fontSize: 11, color: 'rgba(17,17,16,0.65)', margin: 0 }}>Delivered</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .about-grid { grid-template-columns: 1fr !important; gap: 60px !important; }
          .about-card-col { display: flex; justify-content: center; }
        }
      `}</style>
    </section>
  )
}
