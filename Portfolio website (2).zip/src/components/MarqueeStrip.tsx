const items = [
  'UI/UX Design', '·', 'Motion Graphics', '·', 'Visual Design', '·', 'Product Design', '·',
  'Branding', '·', 'SaaS Interfaces', '·', 'Enterprise Applications', '·', 'Brand Identity', '·',
  'UI/UX Design', '·', 'Motion Graphics', '·', 'Visual Design', '·', 'Product Design', '·',
  'Branding', '·', 'SaaS Interfaces', '·', 'Enterprise Applications', '·', 'Brand Identity', '·',
]

export default function MarqueeStrip() {
  return (
    <div
      style={{
        overflow: 'hidden',
        padding: '22px 0',
        borderTop: '1px solid rgba(17,17,16,0.07)',
        borderBottom: '1px solid rgba(17,17,16,0.07)',
        background: '#fff',
      }}
    >
      <div className="marquee-track">
        {items.map((item, i) => (
          <span
            key={i}
            style={{
              fontSize: 12,
              fontWeight: item === '·' ? 400 : 600,
              color: item === '·' ? 'rgba(34,197,94,0.6)' : 'rgba(17,17,16,0.52)',
              letterSpacing: item === '·' ? '0' : '0.1em',
              textTransform: 'uppercase',
              whiteSpace: 'nowrap',
              padding: '0 14px',
            }}
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  )
}
