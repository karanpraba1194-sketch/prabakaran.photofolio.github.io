import { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import CharacterView from './CharacterView'

export default function Hero() {
  const navigate = useNavigate()
  const headRef = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    const el = headRef.current
    if (!el) return
    setTimeout(() => {
      el.style.opacity = '1'
      el.style.transform = 'translateY(0)'
    }, 200)
  }, [])

  const handleWork = () => {
    const el = document.getElementById('work')
    el?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleContact = () => {
    const el = document.getElementById('contact')
    el?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        position: 'relative',
        overflow: 'hidden',
        padding: '72px 40px 80px',
        background: 'var(--bg)',
      }}
    >
      <div
        style={{
          maxWidth: 1400,
          margin: '0 auto',
          width: '100%',
          display: 'grid',
          gridTemplateColumns: '1fr 460px',
          gap: 60,
          alignItems: 'flex-end',
        }}
        className="hero-grid"
      >
        {/* Left column */}
        <div style={{ paddingLeft: '10%' }}>
          {/* Availability badge */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              background: 'rgba(34,197,94,0.08)',
              border: '1px solid rgba(34,197,94,0.2)',
              borderRadius: 100,
              padding: '6px 16px 6px 10px',
              marginBottom: 52,
              opacity: 0,
              transform: 'translateY(16px)',
              transition: 'all 0.6s ease 0.1s',
            }}
            ref={(el) => {
              if (el) setTimeout(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)' }, 100)
            }}
          >
            <span
              style={{
                width: 7,
                height: 7,
                borderRadius: '50%',
                background: '#22C55E',
                display: 'block',
                animation: 'pulse-dot 2.5s ease-in-out infinite',
              }}
            />
            <span style={{ fontSize: 12, fontWeight: 600, color: 'rgba(17,17,16,0.6)', letterSpacing: '0.04em' }}>
              Available for creative opportunities
            </span>
          </div>

          {/* Signature name */}
          <h1
            ref={headRef}
            style={{
              margin: 0,
              marginBottom: 24,
              opacity: 0,
              transform: 'translateY(36px)',
              transition: 'all 0.9s cubic-bezier(0.16, 1, 0.3, 1) 0.2s',
              lineHeight: 1,
            }}
          >
            <span
              style={{
                display: 'block',
                fontFamily: "'Great Vibes', cursive",
                fontWeight: 400,
                fontSize: 'clamp(60px, 8.5vw, 112px)',
                lineHeight: 1.05,
                letterSpacing: '0.01em',
                color: '#111110',
              }}
            >
              Praba{' '}
              <span style={{ color: '#333330' }}>Karan</span>
            </span>
            <span
              style={{
                display: 'block',
                fontFamily: 'Manrope, sans-serif',
                fontWeight: 500,
                fontSize: 'clamp(11px, 1vw, 13px)',
                letterSpacing: '0.26em',
                color: 'rgba(17,17,16,0.60)',
                textTransform: 'uppercase',
                marginTop: 8,
                paddingLeft: 3,
              }}
            >
              Visual Designer
            </span>
          </h1>

          {/* Headline */}
          <p
            style={{
              fontSize: 'clamp(15px, 1.5vw, 17px)',
              fontWeight: 400,
              color: 'rgba(17,17,16,0.78)',
              lineHeight: 1.7,
              margin: 0,
              marginBottom: 14,
              maxWidth: 480,
              opacity: 0,
              transform: 'translateY(24px)',
              transition: 'all 0.8s ease 0.4s',
            }}
            ref={(el) => {
              if (el) setTimeout(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)' }, 400)
            }}
          >
            UI/UX Designer &nbsp;&bull;&nbsp; Motion Graphics Artist &nbsp;&bull;&nbsp; Brand Designer
          </p>

          {/* Tags */}
          <p
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: 'rgba(17,17,16,0.52)',
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              marginBottom: 56,
              opacity: 0,
              transform: 'translateY(16px)',
              transition: 'all 0.8s ease 0.5s',
            }}
            ref={(el) => {
              if (el) setTimeout(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)' }, 500)
            }}
          >
            UI/UX &nbsp;·&nbsp; Visual Design &nbsp;·&nbsp; Motion Graphics &nbsp;·&nbsp; Brand Design
          </p>

          {/* CTAs */}
          <div
            style={{
              display: 'flex',
              gap: 12,
              flexWrap: 'wrap',
              opacity: 0,
              transform: 'translateY(16px)',
              transition: 'all 0.8s ease 0.6s',
            }}
            ref={(el) => {
              if (el) setTimeout(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)' }, 600)
            }}
          >
            <button onClick={handleWork} className="btn-pill">
              View My Work
            </button>
            <button onClick={handleContact} className="btn-outline">
              Let&apos;s Connect
            </button>
          </div>
        </div>

        {/* Right column */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-end',
            opacity: 0,
            transition: 'opacity 1.2s ease 0.7s',
          }}
          ref={(el) => {
            if (el) setTimeout(() => { el.style.opacity = '1' }, 700)
          }}
          className="hero-orb"
        >
          <CharacterView />
        </div>
      </div>

      {/* Scroll hint */}
      <div
        style={{
          position: 'absolute',
          bottom: 40,
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 10,
          opacity: 0,
          transition: 'opacity 1s ease 1.2s',
        }}
        ref={(el) => {
          if (el) setTimeout(() => { el.style.opacity = '1' }, 1200)
        }}
      >
        <span style={{ fontSize: 10, fontWeight: 600, color: 'rgba(17,17,16,0.52)', letterSpacing: '0.16em', textTransform: 'uppercase' }}>
          Scroll
        </span>
        <div
          style={{
            width: 1,
            height: 44,
            background: 'linear-gradient(to bottom, rgba(17,17,16,0.55), transparent)',
            animation: 'float1 2.5s ease-in-out infinite',
          }}
        />
      </div>

      <style>{`
        @media (max-width: 900px) {
          .hero-grid { grid-template-columns: 1fr !important; gap: 40px !important; }
          .hero-orb { display: none !important; }
        }
      `}</style>
    </section>
  )
}
