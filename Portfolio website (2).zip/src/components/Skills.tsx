const skills = [
  {
    name: 'Figma',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="14" y="6" width="11" height="11" rx="5.5" stroke="#111110" strokeWidth="1.5"/>
        <rect x="27" y="6" width="11" height="11" rx="5.5" stroke="#111110" strokeWidth="1.5"/>
        <rect x="14" y="19" width="11" height="11" rx="2" stroke="#111110" strokeWidth="1.5"/>
        <circle cx="32.5" cy="24.5" r="5.5" stroke="#22C55E" strokeWidth="1.5"/>
        <rect x="14" y="32" width="11" height="11" rx="5.5" stroke="#111110" strokeWidth="1.5"/>
      </svg>
    ),
  },
  {
    name: 'After Effects',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <circle cx="26" cy="26" r="18" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="31" textAnchor="middle" fontSize="13" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">Ae</text>
        <circle cx="38" cy="36" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Photoshop',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="10" y="10" width="32" height="32" rx="6" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="31" textAnchor="middle" fontSize="13" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">Ps</text>
        <circle cx="38" cy="14" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Illustrator',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="10" y="10" width="32" height="32" rx="6" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="31" textAnchor="middle" fontSize="13" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">Ai</text>
        <circle cx="38" cy="14" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Premiere Pro',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="10" y="10" width="32" height="32" rx="6" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="31" textAnchor="middle" fontSize="13" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">Pr</text>
        <circle cx="38" cy="14" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Adobe XD',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="26" y="8" width="20" height="20" rx="2" transform="rotate(45 26 8)" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="30" textAnchor="middle" fontSize="11" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">XD</text>
        <circle cx="38" cy="36" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Canva',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <circle cx="26" cy="26" r="18" stroke="#111110" strokeWidth="1.5"/>
        <text x="26" y="30" textAnchor="middle" fontSize="10" fontWeight="600" fill="#111110" fontFamily="Manrope,sans-serif">Canva</text>
        <circle cx="38" cy="36" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'UI/UX Design',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="8" y="12" width="36" height="28" rx="4" stroke="#111110" strokeWidth="1.5"/>
        <line x1="8" y1="20" x2="44" y2="20" stroke="#111110" strokeWidth="1.5"/>
        <rect x="14" y="25" width="10" height="9" rx="1.5" stroke="#22C55E" strokeWidth="1.5"/>
        <line x1="28" y1="27" x2="38" y2="27" stroke="#111110" strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="28" y1="31" x2="35" y2="31" stroke="#111110" strokeWidth="1.5" strokeLinecap="round"/>
        <circle cx="12" cy="16" r="1.5" fill="#22C55E"/>
        <circle cx="17" cy="16" r="1.5" fill="#111110" fillOpacity="0.3"/>
        <circle cx="22" cy="16" r="1.5" fill="#111110" fillOpacity="0.3"/>
      </svg>
    ),
  },
  {
    name: 'Product Design',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <path d="M26 10L40 18V34L26 42L12 34V18L26 10Z" stroke="#111110" strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M26 10V42" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.3"/>
        <path d="M12 18L26 26L40 18" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.3"/>
        <circle cx="40" cy="34" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Motion Graphics',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <circle cx="20" cy="26" r="12" stroke="#111110" strokeWidth="1.5"/>
        <circle cx="32" cy="26" r="12" stroke="#22C55E" strokeWidth="1.5"/>
      </svg>
    ),
  },
  {
    name: 'Visual Design',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <path d="M26 10C26 10 20 18 20 24C20 27.3137 22.6863 30 26 30C29.3137 30 32 27.3137 32 24C32 18 26 10 26 10Z" stroke="#111110" strokeWidth="1.5" strokeLinejoin="round"/>
        <line x1="26" y1="30" x2="26" y2="42" stroke="#111110" strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="20" y1="38" x2="32" y2="38" stroke="#111110" strokeWidth="1.5" strokeLinecap="round"/>
        <circle cx="26" cy="24" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Branding',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <circle cx="26" cy="26" r="18" stroke="#111110" strokeWidth="1.5"/>
        <circle cx="26" cy="26" r="10" stroke="#111110" strokeWidth="1.5"/>
        <circle cx="26" cy="26" r="3" fill="#22C55E"/>
        <circle cx="38" cy="16" r="3" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Video Editing',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        <rect x="8" y="14" width="28" height="24" rx="3" stroke="#111110" strokeWidth="1.5"/>
        <path d="M36 20L46 16V36L36 32V20Z" stroke="#111110" strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M22 22L28 26L22 30V22Z" fill="#22C55E"/>
      </svg>
    ),
  },
  {
    name: 'Storyboarding',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        {/* Back panel — stacked depth */}
        <rect x="14" y="7" width="34" height="22" rx="2.5" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.15"/>
        {/* Mid panel */}
        <rect x="10" y="12" width="34" height="22" rx="2.5" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.3"/>
        {/* Front panel — active frame */}
        <rect x="6" y="17" width="34" height="22" rx="2.5" stroke="#22C55E" strokeWidth="1.5"/>
        {/* Scene: horizon + hills */}
        <path d="M11 35 L17 27 L22 31 L27 25 L38 35" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35" strokeLinejoin="round" strokeLinecap="round"/>
        {/* Sun */}
        <circle cx="35" cy="23" r="3" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.3"/>
        {/* Caption lines */}
        <line x1="6" y1="44" x2="40" y2="44" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.12" strokeLinecap="round"/>
        <line x1="6" y1="48" x2="27" y2="48" stroke="#111110" strokeWidth="1.5" strokeOpacity="0.12" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    name: 'Design Systems',
    icon: (
      <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
        {/* Root atom */}
        <circle cx="26" cy="9" r="5.5" stroke="#22C55E" strokeWidth="1.5"/>
        <circle cx="26" cy="9" r="2" fill="#22C55E"/>
        {/* Trunk line */}
        <line x1="26" y1="14.5" x2="26" y2="21" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35"/>
        {/* Branch line */}
        <line x1="12" y1="21" x2="40" y2="21" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35"/>
        {/* Vertical drops to component boxes */}
        <line x1="12" y1="21" x2="12" y2="26" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35"/>
        <line x1="26" y1="21" x2="26" y2="26" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35"/>
        <line x1="40" y1="21" x2="40" y2="26" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.35"/>
        {/* Component boxes */}
        <rect x="6" y="26" width="12" height="9" rx="2" stroke="#111110" strokeWidth="1.5"/>
        <rect x="20" y="26" width="12" height="9" rx="2" stroke="#111110" strokeWidth="1.5"/>
        <rect x="34" y="26" width="12" height="9" rx="2" stroke="#111110" strokeWidth="1.5"/>
        {/* Sub-lines */}
        <line x1="12" y1="35" x2="12" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
        <line x1="8" y1="41" x2="16" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
        <line x1="26" y1="35" x2="26" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
        <line x1="22" y1="41" x2="30" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
        <line x1="40" y1="35" x2="40" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
        <line x1="36" y1="41" x2="44" y2="41" stroke="#111110" strokeWidth="1.2" strokeOpacity="0.2"/>
      </svg>
    ),
  },
]

export default function Skills() {
  return (
    <section id="skills" style={{ padding: '80px 40px 140px', background: 'var(--bg)' }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <p className="section-label reveal" style={{ marginBottom: 16 }}>Expertise</p>
        <h2
          className="reveal"
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 800,
            fontSize: 'clamp(34px, 4.8vw, 60px)',
            lineHeight: 1.06,
            letterSpacing: '-0.025em',
            margin: 0,
            marginBottom: 56,
            color: '#111110',
          }}
        >
          Tools &amp; Skills
        </h2>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(5, 1fr)',
            gap: 16,
          }}
          className="skills-grid"
        >
          {skills.map((s, i) => (
            <SkillCard key={s.name} skill={s} delay={i * 0.04} />
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 1100px) {
          .skills-grid { grid-template-columns: repeat(4, 1fr) !important; }
        }
        @media (max-width: 768px) {
          .skills-grid { grid-template-columns: repeat(3, 1fr) !important; }
        }
        @media (max-width: 500px) {
          .skills-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
      `}</style>
    </section>
  )
}

function SkillCard({ skill, delay }: { skill: (typeof skills)[0]; delay: number }) {
  return (
    <div className="reveal" style={{ transitionDelay: `${delay}s` }}>
      <div
        style={{
          background: '#fff',
          border: '1px solid rgba(17,17,16,0.07)',
          borderRadius: 20,
          padding: '32px 16px 24px',
          cursor: 'default',
          transition: 'all 0.28s ease',
          boxShadow: '0 1px 6px rgba(17,17,16,0.04)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 16,
          textAlign: 'center',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'translateY(-5px)'
          e.currentTarget.style.boxShadow = '0 12px 40px rgba(17,17,16,0.1)'
          e.currentTarget.style.borderColor = 'rgba(34,197,94,0.25)'
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translateY(0)'
          e.currentTarget.style.boxShadow = '0 1px 6px rgba(17,17,16,0.04)'
          e.currentTarget.style.borderColor = 'rgba(17,17,16,0.07)'
        }}
      >
        <div style={{ width: 52, height: 52, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {skill.icon}
        </div>
        <p
          style={{
            fontFamily: 'Manrope, sans-serif',
            fontWeight: 600,
            fontSize: 14,
            color: '#111110',
            margin: 0,
            letterSpacing: '-0.01em',
            lineHeight: 1.3,
          }}
        >
          {skill.name}
        </p>
      </div>
    </div>
  )
}
