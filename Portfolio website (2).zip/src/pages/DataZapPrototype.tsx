import { useEffect, useState } from 'react'

const dataZapPrototypeUrl =
  'https://www.figma.com/proto/kVd96BkpjeDN70b4mqa8Xe/CR_22228_2025-Loader-Execution-Summary-UI-%E2%80%93-Corrections?node-id=47-841&viewport=-2466%2C-949%2C0.78&t=yDVXacaLhH8rwjtT-1&scaling=min-zoom&content-scaling=fixed&starting-point-node-id=47%3A841&page-id=47%3A2'

const embedUrl = `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(dataZapPrototypeUrl)}`

export default function DataZapPrototype() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="datazap-prototype">
      <section className="datazap-prototype__panel">
        <header className="datazap-prototype__header">
          <div>
            <span>Figma Prototype</span>
            <h1>DataZap</h1>
          </div>
          <a href={dataZapPrototypeUrl} target="_blank" rel="noreferrer">
            Open in Figma <span aria-hidden="true">↗</span>
          </a>
        </header>

        <div className="datazap-prototype__frame">
          {isLoading && (
            <div className="datazap-prototype__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl}
            title="DataZap Figma prototype"
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      </section>

      <style>{`
        .datazap-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 48px;
          background: var(--bg);
        }
        .datazap-prototype__panel {
          max-width: 1500px;
          margin: 0 auto;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .datazap-prototype__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 18px 22px;
          border-bottom: 1px solid var(--border);
        }
        .datazap-prototype__header > div > span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .datazap-prototype__header h1 {
          margin: 4px 0 0;
          color: var(--fg);
          font: 700 18px 'Manrope', sans-serif;
          letter-spacing: -0.02em;
        }
        .datazap-prototype__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .datazap-prototype__frame {
          position: relative;
          min-height: 680px;
          background: var(--bg3);
        }
        .datazap-prototype__frame iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: calc(100vh - 178px);
          min-height: 680px;
          border: 0;
          background: white;
        }
        .datazap-prototype__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .datazap-prototype__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: datazap-figma-spin 0.8s linear infinite;
        }
        .datazap-prototype__loading p {
          margin: 0;
        }
        @keyframes datazap-figma-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .datazap-prototype {
            padding: 92px 12px 24px;
          }
          .datazap-prototype__header {
            align-items: flex-start;
            padding: 15px;
          }
          .datazap-prototype__header h1 {
            font-size: 15px;
          }
          .datazap-prototype__header a {
            padding: 9px 12px;
          }
          .datazap-prototype__frame,
          .datazap-prototype__frame iframe {
            min-height: 600px;
          }
          .datazap-prototype__frame iframe {
            height: calc(100vh - 166px);
          }
        }
      `}</style>
    </main>
  )
}
