import { useEffect } from 'react'
import { useRevealAll } from '../hooks/useReveal'
import Hero from '../components/Hero'
import About from '../components/About'
import ImageGallery from '../components/ImageGallery'
import Work from '../components/Work'
import MotionSection from '../components/MotionSection'
import Skills from '../components/Skills'
import Experience from '../components/Experience'
import Contact from '../components/Contact'
import MarqueeStrip from '../components/MarqueeStrip'

export default function Home() {
  useRevealAll()

  useEffect(() => {
    const sectionId = window.location.hash.slice(1)

    if (!sectionId) {
      window.scrollTo(0, 0)
      return
    }

    requestAnimationFrame(() => {
      document.getElementById(sectionId)?.scrollIntoView()
    })
  }, [])

  return (
    <main>
      <Hero />
      <MarqueeStrip />
      <About />
      <ImageGallery />
      <Work />
      <MotionSection />
      <Skills />
      <Experience />
      <Contact />
    </main>
  )
}
