import { useEffect } from 'react'
import gif01 from '../imports/gif-animation-01.gif'
import gif02 from '../imports/gif-animation-02.gif'
import gif03 from '../imports/gif-animation-03.gif'
import gif04 from '../imports/gif-animation-04.gif'
import gif05 from '../imports/gif-animation-05.gif'
import gif09 from '../imports/gif-animation-09.gif'
import gif11 from '../imports/gif-animation-11.gif'
import gif12 from '../imports/gif-animation-12.gif'
import gif13 from '../imports/gif-animation-13.gif'

const loadingAnimations = [gif02, gif03, gif09]
const animations = [gif01, gif04, gif05]
const bottomAnimations = [gif11, gif12, gif13]

export default function GifCollection() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="gif-collection">
      <section className="gif-compact-row" aria-label="Loading animations">
        {loadingAnimations.map((animation, index) => (
          <div className="gif-card" key={animation}>
            <img
              src={animation}
              alt={`Loading animation ${index + 1}`}
            />
          </div>
        ))}
      </section>

      <section className="gif-grid" aria-label="GIF animation collection">
        {animations.map((animation, index) => (
          <div className="gif-card" key={animation}>
            <img
              src={animation}
              alt={`GIF animation ${index + 1}`}
              loading={index > 3 ? 'lazy' : 'eager'}
            />
          </div>
        ))}
      </section>

      <section className="gif-bottom-row" aria-label="Additional GIF animations">
        {bottomAnimations.map((animation, index) => (
          <div className="gif-card" key={animation}>
            <img
              src={animation}
              alt={`Additional GIF animation ${index + 1}`}
              loading="lazy"
            />
          </div>
        ))}
      </section>

      <style>{`
        .gif-collection {
          min-height: 100vh;
          padding: 112px 40px 72px;
          background: var(--bg);
        }
        .gif-grid {
          max-width: 1280px;
          margin: 0 auto;
          columns: 2;
          column-gap: 24px;
        }
        .gif-compact-row {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 24px;
          max-width: 708px;
          margin: 0 auto 24px;
        }
        .gif-compact-row .gif-card {
          margin: 0;
        }
        .gif-bottom-row {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 24px;
          width: 100%;
          max-width: 1280px;
          margin: 24px auto 0;
        }
        .gif-bottom-row .gif-card {
          aspect-ratio: 1;
          margin: 0;
          position: relative;
        }
        .gif-bottom-row .gif-card img {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: contain;
        }
        .gif-card {
          width: 100%;
          margin: 0 0 24px;
          overflow: hidden;
          break-inside: avoid;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .gif-card img {
          display: block;
          width: 100%;
          height: auto;
        }
        @media (max-width: 768px) {
          .gif-collection {
            padding: 96px 20px 48px;
          }
          .gif-grid {
            columns: 1;
          }
          .gif-compact-row,
          .gif-bottom-row {
            gap: 10px;
          }
          .gif-compact-row {
            margin-bottom: 18px;
          }
          .gif-card {
            margin-bottom: 18px;
          }
        }
      `}</style>
    </main>
  )
}
