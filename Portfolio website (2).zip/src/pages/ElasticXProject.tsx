import { useEffect } from 'react'

export default function ElasticXProject() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="elasticx-project">
      <iframe
        src="https://elasticx.netlify.app/"
        title="ElasticX ERP live project"
        allowFullScreen
      />

      <style>{`
        .elasticx-project {
          width: 100%;
          min-height: 100vh;
          padding-top: 80px;
          background: var(--bg2);
        }
        .elasticx-project iframe {
          display: block;
          width: 100%;
          height: calc(100vh - 80px);
          border: 0;
          background: white;
        }
        @media (max-width: 768px) {
          .elasticx-project {
            padding-top: 72px;
          }
          .elasticx-project iframe {
            height: calc(100vh - 72px);
          }
        }
      `}</style>
    </main>
  )
}
