import { useEffect, useState } from 'react'

const ariPrototypeUrl =
  'https://www.figma.com/proto/0h8rcJc3uQlBlmzlGw39K7/Universal-Connection-Broker-UI-discussion?scaling=min-zoom&content-scaling=fixed&starting-point-node-id=11463%3A12538&node-id=11496-885&page-id=11463%3A11386&t=wHG86O0L0SkvmmVv-1'

const embedUrl = `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(ariPrototypeUrl)}`

export default function AriPrototype() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="ari-prototype">
      <section className="ari-prototype__panel">
        <header className="ari-prototype__header">
          <div>
            <span>Figma Prototype</span>
            <h1>Ari AI</h1>
          </div>
          <a href={ariPrototypeUrl} target="_blank" rel="noreferrer">
            Open in Figma <span aria-hidden="true">↗</span>
          </a>
        </header>

        <div className="ari-prototype__frame">
          {isLoading && (
            <div className="ari-prototype__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl}
            title="Ari AI Figma prototype"
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      </section>

      <style>{`
        .ari-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 48px;
          background: var(--bg);
        }
        .ari-prototype__panel {
          max-width: 1500px;
          margin: 0 auto;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .ari-prototype__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 18px 22px;
          border-bottom: 1px solid var(--border);
        }
        .ari-prototype__header > div > span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .ari-prototype__header h1 {
          margin: 4px 0 0;
          color: var(--fg);
          font: 700 18px 'Manrope', sans-serif;
          letter-spacing: -0.02em;
        }
        .ari-prototype__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .ari-prototype__frame {
          position: relative;
          min-height: 680px;
          background: var(--bg3);
        }
        .ari-prototype__frame iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: calc(100vh - 178px);
          min-height: 680px;
          border: 0;
          background: white;
        }
        .ari-prototype__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .ari-prototype__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: ari-figma-spin 0.8s linear infinite;
        }
        .ari-prototype__loading p {
          margin: 0;
        }
        @keyframes ari-figma-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .ari-prototype {
            padding: 92px 12px 24px;
          }
          .ari-prototype__header {
            align-items: flex-start;
            padding: 15px;
          }
          .ari-prototype__header h1 {
            font-size: 15px;
          }
          .ari-prototype__header a {
            padding: 9px 12px;
          }
          .ari-prototype__frame,
          .ari-prototype__frame iframe {
            min-height: 600px;
          }
          .ari-prototype__frame iframe {
            height: calc(100vh - 166px);
          }
        }
      `}</style>
    </main>
  )
}
