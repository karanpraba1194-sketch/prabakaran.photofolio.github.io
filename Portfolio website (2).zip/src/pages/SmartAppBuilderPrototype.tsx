import { useEffect, useState } from 'react'

const metadataHistoryPrototypeUrl =
  'https://www.figma.com/proto/0uYR40pPfPsIknfjf9VuoJ/CR_2444_2025---CR_3579_2025--CR_323_2026---Meta-Data-changes-History?page-id=11300%3A167&node-id=15338-1263&viewport=5611%2C7623%2C0.37&t=cJqThVZEwwCt4mGy-1&scaling=min-zoom&content-scaling=fixed&starting-point-node-id=15338%3A1263'

const lookupFieldPrototypeUrl =
  'https://www.figma.com/proto/9McM8fMYbccN8eG8I77II0/CR_2594_2025---Enhancement-in-Lookup-Field-Property?page-id=11096%3A61&node-id=11118-104&viewport=1166%2C-3559%2C0.8&t=KRMFAuQsDwLsOWj1-1&scaling=contain&content-scaling=fixed&starting-point-node-id=11118%3A104'

const embedUrl = (url: string) =>
  `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(url)}`

export default function SmartAppBuilderPrototype() {
  const [openPrototype, setOpenPrototype] = useState<string | null>('metadata')

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="smart-app-prototype">
      <PrototypePanel
        id="metadata"
        title="Meta Data Changes History"
        url={metadataHistoryPrototypeUrl}
        isOpen={openPrototype === 'metadata'}
        onToggle={() =>
          setOpenPrototype((current) =>
            current === 'metadata' ? null : 'metadata',
          )
        }
      />
      <PrototypePanel
        id="lookup-field"
        title="Lookup Field Property Enhancement"
        url={lookupFieldPrototypeUrl}
        isOpen={openPrototype === 'lookup-field'}
        onToggle={() =>
          setOpenPrototype((current) =>
            current === 'lookup-field' ? null : 'lookup-field',
          )
        }
      />

      <style>{`
        .smart-app-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 48px;
          background: var(--bg);
        }
        .smart-app-prototype__panel {
          max-width: 1500px;
          margin: 0 auto 28px;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .smart-app-prototype__panel:last-of-type {
          margin-bottom: 0;
        }
        .smart-app-prototype__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 0 22px 0 0;
        }
        .smart-app-prototype__toggle {
          display: flex;
          flex: 1;
          align-items: center;
          gap: 16px;
          min-height: 76px;
          padding: 14px 0 14px 22px;
          border: 0;
          color: inherit;
          background: transparent;
          text-align: left;
          cursor: pointer;
        }
        .smart-app-prototype__toggle-icon {
          display: grid;
          width: 34px;
          height: 34px;
          flex: 0 0 auto;
          place-items: center;
          border: 1px solid var(--border-strong);
          border-radius: 50%;
          color: var(--fg);
          font-size: 16px;
          transition: transform 0.3s ease, color 0.2s ease, background 0.2s ease;
        }
        .smart-app-prototype__toggle[aria-expanded="true"] .smart-app-prototype__toggle-icon {
          color: white;
          background: var(--fg);
          transform: rotate(45deg);
        }
        .smart-app-prototype__toggle > div > span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .smart-app-prototype__header h2 {
          margin: 4px 0 0;
          color: var(--fg);
          font: 700 18px 'Manrope', sans-serif;
          letter-spacing: -0.02em;
        }
        .smart-app-prototype__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .smart-app-prototype__frame {
          position: relative;
          min-height: 680px;
          border-top: 1px solid var(--border);
          background: var(--bg3);
        }
        .smart-app-prototype__frame iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: calc(100vh - 178px);
          min-height: 680px;
          border: 0;
          background: white;
        }
        .smart-app-prototype__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .smart-app-prototype__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: smart-app-figma-spin 0.8s linear infinite;
        }
        .smart-app-prototype__loading p {
          margin: 0;
        }
        @keyframes smart-app-figma-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .smart-app-prototype {
            padding: 92px 12px 24px;
          }
          .smart-app-prototype__header {
            gap: 8px;
            padding-right: 12px;
          }
          .smart-app-prototype__toggle {
            min-height: 68px;
            padding: 12px 0 12px 12px;
          }
          .smart-app-prototype__toggle-icon {
            width: 30px;
            height: 30px;
          }
          .smart-app-prototype__header h2 {
            font-size: 15px;
          }
          .smart-app-prototype__header a {
            padding: 9px 12px;
          }
          .smart-app-prototype__frame,
          .smart-app-prototype__frame iframe {
            min-height: 600px;
          }
          .smart-app-prototype__frame iframe {
            height: calc(100vh - 166px);
          }
        }
      `}</style>
    </main>
  )
}

function PrototypePanel({
  id,
  title,
  url,
  isOpen,
  onToggle,
}: {
  id: string
  title: string
  url: string
  isOpen: boolean
  onToggle: () => void
}) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (isOpen) setIsLoading(true)
  }, [isOpen])

  return (
    <section className="smart-app-prototype__panel">
      <header className="smart-app-prototype__header">
        <button
          type="button"
          className="smart-app-prototype__toggle"
          aria-expanded={isOpen}
          aria-controls={`${id}-prototype`}
          onClick={onToggle}
        >
          <span className="smart-app-prototype__toggle-icon" aria-hidden="true">+</span>
          <div>
            <span>Figma Prototype</span>
            <h2>{title}</h2>
          </div>
        </button>
        <a href={url} target="_blank" rel="noreferrer">
          Open in Figma <span aria-hidden="true">↗</span>
        </a>
      </header>

      {isOpen && (
        <div className="smart-app-prototype__frame" id={`${id}-prototype`}>
          {isLoading && (
            <div className="smart-app-prototype__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl(url)}
            title={`${title} Figma prototype`}
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      )}
    </section>
  )
}
