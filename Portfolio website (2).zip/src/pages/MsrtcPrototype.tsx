import { useEffect, useState } from 'react'

const landingPagePrototypeUrl =
  'https://www.figma.com/proto/zPh6Lcdlw0O4EuyygyXGga/CR_1603_2025-landing-page?node-id=2244-2522&viewport=-2085%2C231%2C0.75&t=OZc59ls8fVB3657u-1&scaling=min-zoom&content-scaling=fixed&starting-point-node-id=2030%3A34&page-id=1%3A4'

const dashboardPrototypeUrl =
  'https://www.figma.com/proto/pBnMdqhfQGjP76reCiZhx1/CR_1629_2025---Implementing-additional-details-in-Works-Manager-Dashboard-in-MSRTC-Dev-Instance?node-id=2110-6&viewport=25%2C179%2C0.89&t=vHRtCbYUlbCXAVOG-1&scaling=min-zoom&content-scaling=fixed&page-id=1%3A4'

const loginPrototypeUrl =
  'https://www.figma.com/proto/Z7iXYblMwHIT81SzCSXd2k/CR_3605_2026_MSRTC-login-page?node-id=2003-121&page-id=1%3A6&t=uLKMSwiu7eqliPkN-1'

const embedUrl = (url: string) =>
  `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(url)}`

export default function MsrtcPrototype() {
  const [openPrototype, setOpenPrototype] = useState<string | null>('landing-page')

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="msrtc-prototype">
      <PrototypeFrame
        id="landing-page"
        title="MSRTS Works"
        url={landingPagePrototypeUrl}
        isOpen={openPrototype === 'landing-page'}
        onToggle={() =>
          setOpenPrototype((current) =>
            current === 'landing-page' ? null : 'landing-page',
          )
        }
      />
      <PrototypeFrame
        id="dashboard"
        title="MSRTC Dashboard Design"
        url={dashboardPrototypeUrl}
        isOpen={openPrototype === 'dashboard'}
        onToggle={() =>
          setOpenPrototype((current) =>
            current === 'dashboard' ? null : 'dashboard',
          )
        }
      />
      <PrototypeFrame
        id="login-page"
        title="MSRTC Login Page"
        url={loginPrototypeUrl}
        isOpen={openPrototype === 'login-page'}
        onToggle={() =>
          setOpenPrototype((current) =>
            current === 'login-page' ? null : 'login-page',
          )
        }
      />

      <style>{`
        .msrtc-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 64px;
          background: var(--bg);
        }
        .msrtc-prototype__frame {
          max-width: 1500px;
          margin: 0 auto 64px;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .msrtc-prototype__frame:last-child {
          margin-bottom: 0;
        }
        .msrtc-prototype__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 0 22px 0 0;
        }
        .msrtc-prototype__toggle {
          display: flex;
          flex: 1;
          align-items: center;
          gap: 16px;
          min-height: 76px;
          padding: 14px 0 14px 22px;
          border: 0;
          color: inherit;
          background: transparent;
          text-align: left;
          cursor: pointer;
        }
        .msrtc-prototype__toggle-icon {
          display: grid;
          width: 34px;
          height: 34px;
          flex: 0 0 auto;
          place-items: center;
          border: 1px solid var(--border-strong);
          border-radius: 50%;
          color: var(--fg);
          font-size: 16px;
          transition: transform 0.3s ease, color 0.2s ease, background 0.2s ease;
        }
        .msrtc-prototype__toggle[aria-expanded="true"] .msrtc-prototype__toggle-icon {
          color: white;
          background: var(--fg);
          transform: rotate(45deg);
        }
        .msrtc-prototype__toggle > div > span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .msrtc-prototype__frame h1,
        .msrtc-prototype__frame h2 {
          margin: 4px 0 0;
          color: var(--fg);
          font-family: 'Manrope', sans-serif;
          font-size: 18px;
          font-weight: 700;
          letter-spacing: -0.02em;
        }
        .msrtc-prototype__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .msrtc-prototype__body {
          position: relative;
          min-height: 640px;
          border-top: 1px solid var(--border);
          background: var(--bg3);
        }
        .msrtc-prototype__body iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: 82vh;
          min-height: 640px;
          border: 0;
          background: white;
        }
        .msrtc-prototype__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .msrtc-prototype__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: msrtc-figma-spin 0.8s linear infinite;
        }
        .msrtc-prototype__loading p {
          margin: 0;
        }
        @keyframes msrtc-figma-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .msrtc-prototype {
            padding: 96px 12px 40px;
          }
          .msrtc-prototype__frame {
            margin-bottom: 48px;
          }
          .msrtc-prototype__header {
            gap: 8px;
            padding-right: 12px;
          }
          .msrtc-prototype__toggle {
            min-height: 68px;
            padding: 12px 0 12px 12px;
          }
          .msrtc-prototype__toggle-icon {
            width: 30px;
            height: 30px;
          }
          .msrtc-prototype__frame h1,
          .msrtc-prototype__frame h2 {
            font-size: 15px;
          }
          .msrtc-prototype__header a {
            padding: 9px 12px;
          }
          .msrtc-prototype__body,
          .msrtc-prototype__body iframe {
            height: 75vh;
            min-height: 520px;
          }
        }
      `}</style>
    </main>
  )
}

function PrototypeFrame({
  id,
  title,
  url,
  isOpen,
  onToggle,
}: {
  id: string
  title: string
  url: string
  isOpen: boolean
  onToggle: () => void
}) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (isOpen) setIsLoading(true)
  }, [isOpen])

  return (
    <section className="msrtc-prototype__frame">
      <header className="msrtc-prototype__header">
        <button
          type="button"
          className="msrtc-prototype__toggle"
          aria-expanded={isOpen}
          aria-controls={`${id}-prototype`}
          onClick={onToggle}
        >
          <span className="msrtc-prototype__toggle-icon" aria-hidden="true">+</span>
          <div>
            <span>Figma Prototype</span>
            <h2>{title}</h2>
          </div>
        </button>
        <a href={url} target="_blank" rel="noreferrer">
          Open in Figma <span aria-hidden="true">↗</span>
        </a>
      </header>
      {isOpen && (
        <div className="msrtc-prototype__body" id={`${id}-prototype`}>
          {isLoading && (
            <div className="msrtc-prototype__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl(url)}
            title={`${title} Figma prototype`}
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      )}
    </section>
  )
}
