import { useEffect, useState } from 'react'

const dataZensePrototypeUrl =
  'https://www.figma.com/proto/x3FkFeC4BJQNM5fKDwhFpm/smartlets?node-id=11001-1080&viewport=33%2C37%2C0.43&t=q9ENjccC5qdajI8Y-1&scaling=min-zoom&content-scaling=fixed&page-id=1%3A4'

const embedUrl = `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(dataZensePrototypeUrl)}`

export default function DataZensePrototype() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="datazense-prototype">
      <section className="datazense-prototype__panel">
        <header className="datazense-prototype__header">
          <div>
            <span>Figma Prototype</span>
            <h1>DataZense</h1>
          </div>
          <a href={dataZensePrototypeUrl} target="_blank" rel="noreferrer">
            Open in Figma <span aria-hidden="true">↗</span>
          </a>
        </header>

        <div className="datazense-prototype__frame">
          {isLoading && (
            <div className="datazense-prototype__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl}
            title="DataZense Figma prototype"
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      </section>

      <style>{`
        .datazense-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 48px;
          background: var(--bg);
        }
        .datazense-prototype__panel {
          max-width: 1500px;
          margin: 0 auto;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .datazense-prototype__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 18px 22px;
          border-bottom: 1px solid var(--border);
        }
        .datazense-prototype__header > div > span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .datazense-prototype__header h1 {
          margin: 4px 0 0;
          color: var(--fg);
          font: 700 18px 'Manrope', sans-serif;
          letter-spacing: -0.02em;
        }
        .datazense-prototype__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .datazense-prototype__frame {
          position: relative;
          min-height: 680px;
          background: var(--bg3);
        }
        .datazense-prototype__frame iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: calc(100vh - 178px);
          min-height: 680px;
          border: 0;
          background: white;
        }
        .datazense-prototype__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .datazense-prototype__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: datazense-figma-spin 0.8s linear infinite;
        }
        .datazense-prototype__loading p {
          margin: 0;
        }
        @keyframes datazense-figma-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .datazense-prototype {
            padding: 92px 12px 24px;
          }
          .datazense-prototype__header {
            align-items: flex-start;
            padding: 15px;
          }
          .datazense-prototype__header h1 {
            font-size: 15px;
          }
          .datazense-prototype__header a {
            padding: 9px 12px;
          }
          .datazense-prototype__frame,
          .datazense-prototype__frame iframe {
            min-height: 600px;
          }
          .datazense-prototype__frame iframe {
            height: calc(100vh - 166px);
          }
        }
      `}</style>
    </main>
  )
}
