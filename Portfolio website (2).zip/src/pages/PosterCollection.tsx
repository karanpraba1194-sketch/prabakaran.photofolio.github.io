import { useEffect, useState } from 'react'

interface Poster {
  id: string
  name: string
  alt: string
}

const posters: Poster[] = [
  {
    id: '1R2icz4omPXsqdPlUGvpVAf0g57iWjShf',
    name: '01',
    alt: 'Poster design from the visual campaign collection',
  },
  {
    id: '19MR5YBdPfi_lFcnfi1L3aGq9bnqU4na7',
    name: '02',
    alt: 'Poster design from the webinar collection',
  },
  {
    id: '1POO7k5yZ2JTqpxinLhwelCZNcj2BOwMW',
    name: '03',
    alt: 'Poster design from the event collection',
  },
  {
    id: '17W23GkE8qKIFKOFQPg6fsz4q3n4L9zZr',
    name: '04',
    alt: 'Poster design from the campaign collection',
  },
  {
    id: '1NtuwKahArYQW9jNKfp8j0f2XUokeAVMj',
    name: 'Mahadevi',
    alt: 'Mahadevi promotional poster design',
  },
]

const imageUrl = (id: string, width = 2000) =>
  `https://drive.google.com/thumbnail?id=${id}&sz=w${width}`

export default function PosterCollection() {
  const [selectedPoster, setSelectedPoster] = useState<Poster | null>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  useEffect(() => {
    if (!selectedPoster) return

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedPoster(null)
    }

    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', closeOnEscape)

    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', closeOnEscape)
    }
  }, [selectedPoster])

  return (
    <main className="poster-collection">
      <section className="poster-grid" aria-label="Poster design collection">
        {posters.map((poster) => (
          <button
            type="button"
            className="poster-card"
            key={poster.id}
            onClick={() => setSelectedPoster(poster)}
            aria-label={`View ${poster.name} poster full size`}
          >
            <img
              src={imageUrl(poster.id)}
              alt={poster.alt}
              loading="lazy"
            />
          </button>
        ))}
      </section>

      {selectedPoster && (
        <div
          className="poster-lightbox"
          role="dialog"
          aria-modal="true"
          aria-label={`${selectedPoster.name} poster preview`}
          onClick={() => setSelectedPoster(null)}
        >
          <button
            type="button"
            className="poster-lightbox__close"
            onClick={() => setSelectedPoster(null)}
            aria-label="Close poster preview"
            autoFocus
          >
            <span aria-hidden="true">×</span>
          </button>
          <img
            src={imageUrl(selectedPoster.id, 3000)}
            alt={selectedPoster.alt}
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      )}

      <style>{`
        .poster-collection {
          min-height: 100vh;
          padding: 112px 40px 80px;
          background: var(--bg);
        }
        .poster-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 28px;
          max-width: 1400px;
          margin: 0 auto;
        }
        .poster-card {
          position: relative;
          display: block;
          width: 100%;
          padding: 0;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--card-bg);
          box-shadow: var(--card-shadow);
          cursor: zoom-in;
          text-align: left;
          transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.35s ease;
        }
        .poster-card:nth-child(3n) {
          grid-column: 1 / -1;
        }
        .poster-card:hover {
          transform: translateY(-6px);
          box-shadow: var(--card-shadow-hover);
        }
        .poster-card:focus-visible,
        .poster-lightbox__close:focus-visible {
          outline: 3px solid var(--accent-green);
          outline-offset: 4px;
        }
        .poster-card img {
          display: block;
          width: 100%;
          height: auto;
          min-height: 320px;
          max-height: 880px;
          object-fit: contain;
          background: #ebe9e2;
          transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .poster-card:hover img {
          transform: scale(1.015);
        }
        .poster-lightbox {
          position: fixed;
          z-index: 2000;
          inset: 0;
          display: grid;
          place-items: center;
          padding: 72px 40px 48px;
          background: rgba(10, 10, 9, 0.94);
          backdrop-filter: blur(18px);
          cursor: zoom-out;
        }
        .poster-lightbox img {
          max-width: min(1200px, 90vw);
          max-height: 82vh;
          object-fit: contain;
          border-radius: 10px;
          box-shadow: 0 32px 100px rgba(0, 0, 0, 0.45);
          cursor: default;
        }
        .poster-lightbox__close {
          position: absolute;
          top: 24px;
          right: 28px;
          display: grid;
          width: 42px;
          height: 42px;
          place-items: center;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 50%;
          color: white;
          background: rgba(255, 255, 255, 0.08);
          font-size: 25px;
          line-height: 1;
          cursor: pointer;
        }
        @media (max-width: 768px) {
          .poster-collection {
            padding: 96px 20px 56px;
          }
          .poster-grid {
            grid-template-columns: 1fr;
            gap: 18px;
          }
          .poster-card:nth-child(3n) {
            grid-column: auto;
          }
          .poster-card img {
            min-height: 220px;
          }
          .poster-lightbox {
            padding: 72px 16px 48px;
          }
          .poster-lightbox img {
            max-width: 100%;
          }
        }
      `}</style>
    </main>
  )
}
