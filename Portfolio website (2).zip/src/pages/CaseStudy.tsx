import { useParams, useNavigate } from 'react-router-dom'
import { useEffect } from 'react'
import { projects } from '../data/projects'
import { useRevealAll } from '../hooks/useReveal'
import Nav from '../components/Nav'

export default function CaseStudy() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  useRevealAll()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [id])

  const idx = projects.findIndex((p) => p.id === id)
  const project = projects[idx]

  if (!project) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <h2 style={{ color: '#fff', marginBottom: 16 }}>Project not found</h2>
          <button
            onClick={() => navigate('/')}
            style={{ background: 'linear-gradient(135deg, #6c63ff, #2194e9)', border: 'none', borderRadius: 100, color: '#fff', padding: '12px 28px', cursor: 'pointer', fontFamily: 'Manrope', fontWeight: 700 }}
          >
            Back to Home
          </button>
        </div>
      </div>
    )
  }

  const prev = idx > 0 ? projects[idx - 1] : null
  const next = idx < projects.length - 1 ? projects[idx + 1] : null

  return (
    <div style={{ minHeight: '100vh', background: '#080808' }}>
      <Nav />

      {/* Hero */}
      <section style={{ paddingTop: 120, paddingBottom: 80, padding: '120px 40px 80px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          {/* Back */}
          <button
            onClick={() => navigate('/')}
            style={{
              background: 'none',
              border: 'none',
              color: 'rgba(255,255,255,0.4)',
              fontFamily: 'Manrope, sans-serif',
              fontWeight: 600,
              fontSize: 13,
              cursor: 'pointer',
              letterSpacing: '0.06em',
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 48,
              padding: 0,
              transition: 'color 0.2s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = '#fff')}
            onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.4)')}
          >
            ← Back to Work
          </button>

          <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
            <span
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: project.color,
                background: `${project.color}15`,
                border: `1px solid ${project.color}30`,
                borderRadius: 100,
                padding: '4px 14px',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
              }}
            >
              {project.tag}
            </span>
            <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)', fontWeight: 600 }}>{project.year}</span>
          </div>

          <h1
            style={{
              fontFamily: 'Manrope, sans-serif',
              fontWeight: 800,
              fontSize: 'clamp(40px, 6vw, 80px)',
              lineHeight: 1.0,
              letterSpacing: '-0.03em',
              color: '#fff',
              margin: 0,
              marginBottom: 20,
            }}
          >
            {project.title}
          </h1>
          <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.5)', maxWidth: 600, lineHeight: 1.7, margin: 0 }}>
            {project.desc}
          </p>
        </div>
      </section>

      {/* Hero image */}
      <div style={{ padding: '0 40px', maxWidth: 1200, margin: '0 auto 100px' }}>
        <div
          style={{
            borderRadius: 24,
            overflow: 'hidden',
            height: 500,
            background: `${project.color}10`,
            border: `1px solid ${project.color}20`,
          }}
        >
          <img
            src={project.img.replace('w=800&h=500', 'w=1400&h=700')}
            alt={project.title}
            style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          />
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '0 40px 100px', maxWidth: 1200, margin: '0 auto' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 280px',
            gap: 80,
            alignItems: 'start',
          }}
          className="case-grid"
        >
          {/* Main content */}
          <div>
            {[
              {
                label: 'Overview',
                content: `${project.title} represents a major design challenge in the ${project.category} space. The goal was to create an interface that balances complexity and clarity — giving users powerful tools without cognitive overload. Every design decision was driven by real user needs and business goals.`,
              },
              {
                label: 'The Challenge',
                content: `The primary challenge was translating complex workflows into an intuitive visual system. Users needed to accomplish sophisticated tasks quickly, while the interface needed to remain accessible to different experience levels. Competing priorities required careful hierarchy and progressive disclosure.`,
              },
              {
                label: 'My Approach',
                content: `I started with deep research — user interviews, competitor analysis, and workflow mapping. From there I built a clear design system foundation before moving into high-fidelity screens. Every component was designed with reusability and scalability in mind, ensuring consistency across the entire product.`,
              },
              {
                label: 'Design Process',
                content: `The process moved through discovery → information architecture → wireframes → visual design → prototype → iteration. Key milestones included defining the design language, building the component library, and aligning with engineering on implementation feasibility. Multiple rounds of user testing refined the final designs.`,
              },
            ].map((s) => (
              <div key={s.label} className="reveal" style={{ marginBottom: 56 }}>
                <h3
                  style={{
                    fontFamily: 'Manrope, sans-serif',
                    fontWeight: 700,
                    fontSize: 22,
                    color: '#fff',
                    margin: 0,
                    marginBottom: 16,
                    letterSpacing: '-0.01em',
                  }}
                >
                  {s.label}
                </h3>
                <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.5)', lineHeight: 1.8, margin: 0 }}>
                  {s.content}
                </p>
              </div>
            ))}

            {/* Second image */}
            <div className="reveal" style={{ marginBottom: 56 }}>
              <div
                style={{
                  borderRadius: 20,
                  overflow: 'hidden',
                  height: 360,
                  background: `${project.color}08`,
                  border: `1px solid ${project.color}15`,
                  marginBottom: 12,
                }}
              >
                <img
                  src={project.img.replace('w=800&h=500', 'w=900&h=540')}
                  alt={`${project.title} detail`}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', filter: 'brightness(0.9)' }}
                />
              </div>
              <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.25)', textAlign: 'center' }}>
                {project.title} — Final UI screens
              </p>
            </div>

            {[
              {
                label: 'Results',
                content: `The final design delivered a measurable improvement in user task completion rates and overall satisfaction scores. The design system created during this project became the foundation for subsequent product development, reducing future design and development time significantly.`,
              },
            ].map((s) => (
              <div key={s.label} className="reveal" style={{ marginBottom: 40 }}>
                <h3
                  style={{
                    fontFamily: 'Manrope, sans-serif',
                    fontWeight: 700,
                    fontSize: 22,
                    color: '#fff',
                    margin: 0,
                    marginBottom: 16,
                  }}
                >
                  {s.label}
                </h3>
                <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.5)', lineHeight: 1.8, margin: 0 }}>
                  {s.content}
                </p>
              </div>
            ))}
          </div>

          {/* Sticky sidebar */}
          <div style={{ position: 'sticky', top: 100 }} className="case-sidebar">
            <div
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.07)',
                borderRadius: 16,
                padding: 28,
              }}
            >
              <h4 style={{ fontFamily: 'Manrope', fontWeight: 700, fontSize: 13, color: 'rgba(255,255,255,0.3)', letterSpacing: '0.12em', textTransform: 'uppercase', margin: '0 0 20px' }}>
                Project Info
              </h4>

              {[
                { label: 'Category', value: project.category },
                { label: 'Year', value: project.year },
              ].map((row) => (
                <div key={row.label} style={{ marginBottom: 16, paddingBottom: 16, borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 4px' }}>
                    {row.label}
                  </p>
                  <p style={{ fontSize: 14, color: '#fff', fontWeight: 600, margin: 0 }}>{row.value}</p>
                </div>
              ))}

              <div>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', margin: '0 0 10px' }}>
                  Tools Used
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {project.tools.map((t) => (
                    <span
                      key={t}
                      style={{
                        fontSize: 11,
                        fontWeight: 600,
                        color: project.color,
                        background: `${project.color}12`,
                        border: `1px solid ${project.color}25`,
                        borderRadius: 8,
                        padding: '4px 10px',
                      }}
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Prev / Next */}
      <div
        style={{
          padding: '60px 40px 80px',
          borderTop: '1px solid rgba(255,255,255,0.05)',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 20,
          maxWidth: 1200,
          margin: '0 auto',
        }}
        className="prev-next"
      >
        {prev ? (
          <button
            onClick={() => navigate(`/project/${prev.id}`)}
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.07)',
              borderRadius: 16,
              padding: '24px 28px',
              cursor: 'pointer',
              textAlign: 'left',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.05)'
              e.currentTarget.style.borderColor = `${prev.color}30`
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.03)'
              e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)'
            }}
          >
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', margin: '0 0 8px' }}>
              ← Previous
            </p>
            <p style={{ fontSize: 18, fontFamily: 'Manrope', fontWeight: 700, color: '#fff', margin: 0 }}>{prev.title}</p>
          </button>
        ) : <div />}

        {next ? (
          <button
            onClick={() => navigate(`/project/${next.id}`)}
            style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.07)',
              borderRadius: 16,
              padding: '24px 28px',
              cursor: 'pointer',
              textAlign: 'right',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.05)'
              e.currentTarget.style.borderColor = `${next.color}30`
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.03)'
              e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)'
            }}
          >
            <p style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', margin: '0 0 8px' }}>
              Next →
            </p>
            <p style={{ fontSize: 18, fontFamily: 'Manrope', fontWeight: 700, color: '#fff', margin: 0 }}>{next.title}</p>
          </button>
        ) : <div />}
      </div>

      <style>{`
        @media (max-width: 900px) {
          .case-grid { grid-template-columns: 1fr !important; }
          .case-sidebar { position: static !important; }
          .prev-next { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  )
}
