import { useEffect, useState } from 'react'

const templateHubUrl =
  'https://www.figma.com/make/0HzHNce1Zwv2VZ9kMUOOwq/Chainsys-Template-Hub-v7?t=pVnCbxHzMvLgkyBo-1'

const embedUrl = `https://www.figma.com/embed?embed_host=share&url=${encodeURIComponent(templateHubUrl)}`

export default function TemplateHubPrototype() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="template-hub-prototype">
      <section className="template-hub-panel">
        <header className="template-hub-panel__header">
          <div>
            <span>Figma Make</span>
            <h1>ChainSys Template Hub</h1>
          </div>
          <a href={templateHubUrl} target="_blank" rel="noreferrer">
            Open in Figma <span aria-hidden="true">↗</span>
          </a>
        </header>

        <div className="template-hub-panel__frame">
          {isLoading && (
            <div className="template-hub-panel__loading" role="status">
              <span aria-hidden="true" />
              <p>Loading Figma file…</p>
            </div>
          )}
          <iframe
            src={embedUrl}
            title="ChainSys Template Hub Figma file"
            allowFullScreen
            onLoad={() => setIsLoading(false)}
          />
        </div>
      </section>

      <style>{`
        .template-hub-prototype {
          width: 100%;
          min-height: 100vh;
          padding: 112px 24px 48px;
          background: var(--bg);
        }
        .template-hub-panel {
          max-width: 1500px;
          margin: 0 auto;
          overflow: hidden;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          background: var(--bg2);
          box-shadow: var(--card-shadow);
        }
        .template-hub-panel__header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 24px;
          padding: 18px 22px;
          border-bottom: 1px solid var(--border);
          background: var(--bg2);
        }
        .template-hub-panel__header span {
          color: var(--accent-green);
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }
        .template-hub-panel__header h1 {
          margin: 4px 0 0;
          color: var(--fg);
          font: 700 18px 'Manrope', sans-serif;
          letter-spacing: -0.02em;
        }
        .template-hub-panel__header a {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 10px 16px;
          border-radius: 100px;
          color: white;
          background: var(--fg);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-decoration: none;
          white-space: nowrap;
        }
        .template-hub-panel__header a span {
          color: white;
          font-size: 13px;
          letter-spacing: 0;
        }
        .template-hub-panel__frame {
          position: relative;
          min-height: 680px;
          background: var(--bg3);
        }
        .template-hub-panel__frame iframe {
          position: relative;
          z-index: 1;
          display: block;
          width: 100%;
          height: calc(100vh - 178px);
          min-height: 680px;
          border: 0;
          background: transparent;
        }
        .template-hub-panel__loading {
          position: absolute;
          z-index: 2;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          gap: 16px;
          color: rgba(17, 17, 16, 0.56);
          background: var(--bg3);
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }
        .template-hub-panel__loading > span {
          width: 38px;
          height: 38px;
          border: 3px solid rgba(17, 17, 16, 0.12);
          border-top-color: var(--accent-green);
          border-radius: 50%;
          animation: figma-panel-spin 0.8s linear infinite;
        }
        .template-hub-panel__loading p {
          margin: 0;
        }
        @keyframes figma-panel-spin {
          to { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
          .template-hub-prototype {
            padding: 92px 12px 24px;
          }
          .template-hub-panel__header {
            align-items: flex-start;
            padding: 15px;
          }
          .template-hub-panel__header h1 {
            font-size: 15px;
          }
          .template-hub-panel__header a {
            padding: 9px 12px;
          }
          .template-hub-panel__frame,
          .template-hub-panel__frame iframe {
            min-height: 600px;
          }
          .template-hub-panel__frame iframe {
            height: calc(100vh - 166px);
          }
        }
      `}</style>
    </main>
  )
}
