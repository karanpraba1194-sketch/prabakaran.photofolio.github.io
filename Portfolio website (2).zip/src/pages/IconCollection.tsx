import { useEffect } from 'react'
import iconCollection from '../imports/business-tech-icons-full.webp'

export default function IconCollection() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <main className="icon-collection">
      <img
        src={iconCollection}
        alt="Business and technology icon collection"
      />

      <style>{`
        .icon-collection {
          min-height: 100vh;
          padding: 112px 24px 64px;
          background: var(--bg2);
        }
        .icon-collection img {
          display: block;
          width: min(100%, 1100px);
          height: auto;
          margin: 0 auto;
        }
        @media (max-width: 768px) {
          .icon-collection {
            padding: 92px 0 32px;
          }
        }
      `}</style>
    </main>
  )
}
