Create a premium, modern, immersive personal portfolio website for a senior Visual Designer / UI/UX Designer / Motion Graphics Designer.

The website should feel like a high-end creative studio portfolio with a strong 3D visual identity. Avoid a generic corporate portfolio template. Make it visually impressive, minimal, sophisticated, interactive and highly polished.

## DESIGN DIRECTION

Style:

* Futuristic creative portfolio
* Premium 3D visual design
* Dark mode as the primary theme
* Black / charcoal background
* White and soft-gray typography
* Subtle electric-blue and violet accent lighting
* Glassmorphism used carefully
* Soft gradients
* Large typography
* Strong visual hierarchy
* Generous whitespace
* Cinematic lighting
* Subtle grain/noise texture
* High-quality 3D objects and abstract shapes
* Depth, shadows, reflections and floating elements
* Smooth scrolling
* Micro-interactions
* Parallax movement
* Hover animations
* Smooth page transitions

The overall feeling should be:
"Creative designer + technology + motion + 3D + product design."

Do not make it look like a normal resume website.

## HERO SECTION

Create a full-screen cinematic hero section.

Display:

"PRABA KARAN"

Headline:
"Visual Designer crafting digital experiences, products & motion."

Supporting text:
"UI/UX • Visual Design • Motion Graphics • Brand Design"

Include a large abstract 3D centerpiece on the right side:

* Floating 3D geometric forms
* Glass-like surfaces
* Metallic elements
* Soft blue/violet lighting
* Subtle particle effects
* Slow rotation
* Deep shadows
* Premium CGI appearance

Add two CTA buttons:

"View My Work"
"Let's Connect"

Add a small availability/status indicator:
"Available for creative opportunities"

At the bottom of the hero:
"Scroll to explore ↓"

Make the hero responsive and visually balanced.

## ABOUT SECTION

Create a clean but visually interesting About section.

Heading:
"Designing with purpose. Creating with impact."

Introduce me as a designer with 9+ years of professional experience across visual design, motion graphics and UI/UX.

Mention my experience working on:

* Product design
* UI/UX design
* SaaS interfaces
* Enterprise applications
* Motion graphics
* Product demo videos
* Branding
* Marketing visuals
* Website design
* Animation

Create a floating 3D profile/card element beside the text.

Include a small timeline:

2017 — Started creative journey
2018–2025 — Motion Graphics / Visual Design
2025–Present — UI/UX & Product Design

Keep the content concise and premium.

## WORK / PROJECTS SECTION

Create the main portfolio showcase.

Heading:
"Selected Work"

Subheading:
"A collection of products, interfaces, visual systems and motion experiences."

Create a large interactive project gallery.

Use an asymmetric editorial layout instead of a basic card grid.

Each project should have:

* Large visual preview
* Project title
* Category
* Short description
* Year
* Tools used
* Hover animation
* Subtle 3D depth

Project categories:

UI/UX DESIGN
MOTION GRAPHICS
VISUAL DESIGN
BRANDING
PRODUCT DESIGN
WEBSITE DESIGN

Include filtering buttons:
"All"
"UI/UX"
"Motion"
"Visual"
"Branding"
"Product"

Featured projects to showcase:

1. ElasticX ERP
   Category: Product Design / UI UX
   Show modern enterprise SaaS dashboards and product interfaces.

2. Smart App Builder
   Category: Product Design
   Show pipeline UI and complex workflow design.

3. DataZap
   Category: UI/UX
   Show data migration and data extraction interfaces.

4. ElasticX Website
   Category: Web Design
   Show modern SaaS website screens.

5. Ari AI
   Category: Character / Motion
   Show the Ari mascot and AI animation work.

6. MSRTC Landing Page
   Category: Web Design

7. Template Hub
   Category: Product / Web Design

8. Smartlet ETL Dashboard
   Category: UI/UX / Data Visualization

9. Currency Exchange Workbench
   Category: Product Design

10. SAB LLM / LogLens
    Category: Branding / Product Design

Use large visual previews and allow each project to open into a detailed case-study page.

## CASE STUDY EXPERIENCE

When a project is clicked, create a premium case-study page.

Structure:

Project title
Project category
Year

Hero image / video

Overview

The Challenge

My Approach

Design Process

Wireframes

Visual Design

Final UI

Motion / Interaction

Results

Tools Used

Include large images and mockups.

Use sticky project information on desktop.

Add:
"Previous Project"
"Next Project"

with smooth transitions.

## UI/UX SECTION

Create a dedicated section highlighting product design skills.

Heading:
"Interfaces built for people and products."

Show 3D floating browser/device mockups containing UI screens.

Include:

* SaaS dashboards
* Enterprise applications
* Mobile applications
* Data visualization
* Design systems
* Workflow interfaces

Use subtle perspective and depth.

## MOTION DESIGN SECTION

Create a visually dramatic section for motion graphics.

Heading:
"Motion that brings ideas to life."

Use a horizontal scrolling gallery of video thumbnails.

Show:

* Product demo videos
* Explainer animations
* Motion graphics
* Logo animations
* Social media videos
* Brand films

Add play buttons and hover motion.

Use cinematic presentation rather than standard video cards.

## SKILLS SECTION

Create a modern interactive skills section.

Show skills as floating 3D tags or objects.

Skills:

Figma
Adobe After Effects
Adobe Photoshop
Adobe Illustrator
Adobe Premiere Pro
Adobe XD
Canva
UI/UX Design
Product Design
Motion Graphics
Visual Design
Branding
Video Editing
Storyboarding
Design Systems

Animate the skills subtly when scrolling.

## EXPERIENCE SECTION

Create a clean timeline section.

Heading:
"Experience"

Company:
Chainsys

Role:
Visual Designer / UI/UX Designer

Experience:
9+ Years

Show progression from Motion Graphics / Visual Design into UI/UX and Product Design.

Keep this section professional and easy for recruiters to scan.

## CONTACT SECTION

Create a strong final CTA.

Large heading:

"Have an idea worth building?"

Supporting text:
"Let's create something meaningful, useful and visually unforgettable."

Buttons:

"Email Me"
"LinkedIn"
"Behance"

Also show:

Behance:
behance.net/karanpraba6656

Create a large abstract 3D object in the background with subtle animation.

## NAVIGATION

Create a minimal floating navigation bar.

Logo:
"PK"

Navigation:

WORK
ABOUT
EXPERIENCE
SKILLS
CONTACT

Add a theme toggle:
Dark / Light

Make the navbar transparent/glass with backdrop blur.

It should become slightly smaller when scrolling.

## INTERACTIONS

Use premium micro-interactions throughout:

* Smooth scrolling
* Magnetic buttons
* Cursor-following glow
* 3D hover effects
* Project image zoom
* Parallax layers
* Floating 3D elements
* Smooth page transitions
* Text reveal animations
* Image reveal animations
* Scroll-triggered animations
* Hover states
* Subtle cursor interaction

Animations should feel sophisticated and smooth, not excessive.

## TYPOGRAPHY

Use a modern premium sans-serif font.

Prefer:
Inter / Satoshi / Manrope / Space Grotesk

Use:

* Very large hero typography
* Bold headlines
* Medium body text
* Tight typography hierarchy

## COLOR SYSTEM

Primary background:
#080808

Secondary background:
#111111

Primary text:
#FFFFFF

Secondary text:
#A5A5A5

Accent:
#6C63FF

Secondary accent:
#2194E9

Use gradients sparingly.

Avoid excessive colors.

## RESPONSIVE DESIGN

Design for:

Desktop: 1440px
Laptop: 1280px
Tablet: 768px
Mobile: 390px

The experience must remain premium on mobile.

On mobile:

* Simplify 3D objects
* Use single-column layouts
* Keep typography readable
* Maintain smooth animations
* Convert horizontal galleries into swipeable sections

## IMPORTANT DESIGN RULES

Do NOT create:

* Generic portfolio cards
* Generic corporate website
* Excessive rounded cards
* Excessive gradients
* Excessive glassmorphism
* Stock-photo-heavy layouts
* Crowded UI
* Too much text

Prioritize:

* Strong typography
* Large visuals
* 3D depth
* Motion
* White space
* Editorial composition
* Premium interaction design
* Recruiter-friendly navigation

The final website should feel like an award-winning creative designer portfolio combining the visual language of a premium digital studio, modern SaaS product design and cinematic 3D art.

Make the design visually distinctive enough that someone immediately understands that the person behind the website is a Visual Designer, UI/UX Designer and Motion Graphics Designer.
