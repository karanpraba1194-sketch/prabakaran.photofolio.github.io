import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { ThemeProvider } from './context/ThemeContext'
import Nav from './components/Nav'
import Home from './pages/Home'
import CaseStudy from './pages/CaseStudy'
import PosterCollection from './pages/PosterCollection'
import IconCollection from './pages/IconCollection'
import GifCollection from './pages/GifCollection'
import ElasticXProject from './pages/ElasticXProject'
import MsrtcPrototype from './pages/MsrtcPrototype'
import TemplateHubPrototype from './pages/TemplateHubPrototype'
import AriPrototype from './pages/AriPrototype'
import DataZensePrototype from './pages/DataZensePrototype'
import DataZapPrototype from './pages/DataZapPrototype'
import SmartAppBuilderPrototype from './pages/SmartAppBuilderPrototype'

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Nav />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/project/:id" element={<CaseStudy />} />
          <Route path="/poster-design" element={<PosterCollection />} />
          <Route path="/icons" element={<IconCollection />} />
          <Route path="/gif-animation" element={<GifCollection />} />
          <Route path="/elasticx" element={<ElasticXProject />} />
          <Route path="/msrtc" element={<MsrtcPrototype />} />
          <Route path="/template-hub" element={<TemplateHubPrototype />} />
          <Route path="/ari-ai" element={<AriPrototype />} />
          <Route path="/datazense" element={<DataZensePrototype />} />
          <Route path="/datazap" element={<DataZapPrototype />} />
          <Route path="/smart-app-builder" element={<SmartAppBuilderPrototype />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  )
}
