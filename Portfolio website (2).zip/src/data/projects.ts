import gifAnimationPoster from '../imports/gif-animation-poster.png'
import msrtcWorkThumbnail from '../imports/msrtc-work-thumbnail.png'
import templateHubThumbnail from '../imports/template-hub-thumbnail.png'
import smartAppBuilderThumbnail from '../imports/smart-app-builder-thumbnail.png'
import elasticxErpThumbnail from '../imports/elasticx-erp-thumbnail.png'
import dataZenseThumbnail from '../imports/datazense-thumbnail.png'
import dataZapThumbnail from '../imports/datazap-thumbnail.png'
import ariAiThumbnail from '../imports/ari-ai-thumbnail.png'

export interface Project {
  id: string
  title: string
  category: string
  tag: string
  desc: string
  year: string
  tools: string[]
  color: string
  accent: string
  img: string
  featured?: boolean
}

export const projects: Project[] = [
  {
    id: 'elasticx-erp',
    title: 'ElasticX ERP Website',
    category: 'Product Design / UI/UX',
    tag: 'Product',
    desc: 'Modern enterprise SaaS platform — complex dashboards, multi-module navigation, and data-dense product interfaces built for scale.',
    year: '2024',
    tools: ['Figma', 'Adobe XD', 'Illustrator'],
    color: '#6c63ff',
    accent: 'rgba(108,99,255,0.15)',
    img: elasticxErpThumbnail,
    featured: true,
  },
  {
    id: 'smart-app-builder',
    title: 'DataZense',
    category: 'Product Design',
    tag: 'Product',
    desc: 'Visual pipeline builder with drag-and-drop workflow design, complex node-based interactions, and enterprise configuration flows.',
    year: '2024',
    tools: ['Figma', 'Principle', 'Illustrator'],
    color: '#2194e9',
    accent: 'rgba(33,148,233,0.15)',
    img: dataZenseThumbnail,
    featured: true,
  },
  {
    id: 'datazap',
    title: 'GIF Animation',
    category: 'Motion Design / GIF',
    tag: 'Motion',
    desc: 'A playful collection of short, looping GIF animations created for expressive product moments and visual storytelling.',
    year: '2023',
    tools: ['After Effects', 'Illustrator'],
    color: '#a78bfa',
    accent: 'rgba(167,139,250,0.15)',
    img: gifAnimationPoster,
  },
  {
    id: 'elasticx-website',
    title: 'DataZap',
    category: 'Web Design',
    tag: 'Visual',
    desc: 'Modern SaaS marketing website — compelling storytelling, animated sections, conversion-focused landing pages.',
    year: '2023',
    tools: ['Figma', 'Illustrator', 'After Effects'],
    color: '#38bdf8',
    accent: 'rgba(56,189,248,0.15)',
    img: dataZapThumbnail,
  },
  {
    id: 'ari-ai',
    title: 'Ari AI',
    category: 'Character / Motion',
    tag: 'Motion',
    desc: 'AI mascot design and full animation system — character rigging, motion personality, product explainer films, and brand animations.',
    year: '2024',
    tools: ['After Effects', 'Illustrator', 'Premiere Pro'],
    color: '#f472b6',
    accent: 'rgba(244,114,182,0.15)',
    img: ariAiThumbnail,
    featured: true,
  },
  {
    id: 'msrtc',
    title: 'MSRTS Works',
    category: 'Web Design',
    tag: 'Visual',
    desc: 'Government transport authority landing page redesign — accessible, trustworthy, and clear information hierarchy.',
    year: '2022',
    tools: ['Figma', 'Photoshop'],
    color: '#34d399',
    accent: 'rgba(52,211,153,0.15)',
    img: msrtcWorkThumbnail,
  },
  {
    id: 'template-hub',
    title: 'Template Hub',
    category: 'Product / Web Design',
    tag: 'Product',
    desc: 'Template marketplace with rich preview experiences, category browsing, and seamless download/purchase flows.',
    year: '2023',
    tools: ['Figma', 'Illustrator'],
    color: '#fb923c',
    accent: 'rgba(251,146,60,0.15)',
    img: templateHubThumbnail,
  },
  {
    id: 'smartlet-etl',
    title: 'Smart App Builder',
    category: 'UI/UX / Data Visualization',
    tag: 'UI/UX',
    desc: 'Real-time ETL monitoring dashboard with complex data visualization, pipeline health indicators, and alert management.',
    year: '2023',
    tools: ['Figma', 'Adobe XD'],
    color: '#6c63ff',
    accent: 'rgba(108,99,255,0.15)',
    img: smartAppBuilderThumbnail,
  },
  {
    id: 'currency-exchange',
    title: 'Currency Exchange Workbench',
    category: 'Product Design',
    tag: 'Product',
    desc: 'Professional currency exchange trading interface — real-time rates, multi-currency workflows, compliance-ready design.',
    year: '2022',
    tools: ['Figma', 'Illustrator'],
    color: '#2194e9',
    accent: 'rgba(33,148,233,0.15)',
    img: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=500&fit=crop&auto=format',
  },
  {
    id: 'sab-loglens',
    title: 'SAB LLM / LogLens',
    category: 'Branding / Product Design',
    tag: 'Branding',
    desc: 'End-to-end brand identity and product design for an AI-powered log analysis tool — visual language, UI system, marketing assets.',
    year: '2024',
    tools: ['Figma', 'Illustrator', 'After Effects'],
    color: '#a78bfa',
    accent: 'rgba(167,139,250,0.15)',
    img: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=500&fit=crop&auto=format',
  },
]

export const filters = ['All', 'UI/UX', 'Motion', 'Visual', 'Branding', 'Product']
